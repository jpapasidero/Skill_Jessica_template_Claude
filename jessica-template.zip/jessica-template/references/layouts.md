# Layouts Pixel-Perfect — Template Safran "Palette Jessica" (V2.3 — 11 layouts)

Ce fichier contient les spécifications **exactes** (positions, dimensions, couleurs, typographie) pour chacun des 11 layouts du template Safran "Palette Jessica".

**Toutes les valeurs ci-dessous sont issues d'un audit OOXML direct du fichier `Template_Palette_Jessica.pptx`** (unpack + lecture des `<a:off>` / `<a:ext>` / `<a:srgbClr>`). Fiabilité maximale.

> 🆕 **V2.3 (mai 2026)** — Mises à jour issues d'annotations manuscrites sur impression du test V2.2 :
> - L1 : mots clés en emphase manifesto/sous-narration → bold NOIR (au lieu de bold couleur palette) ; sous-labels KPI 10 pt → `#474E67` (au lieu de NOIR).
> - L5 : ajout d'une ligne horizontale `#FEE3CA` après la 4ème puce (pour cohérence avec les 3 autres puces).
> - L7 : bloc complet centré horizontalement (décalage +0,315 cm sur tous les x) ; labels gauche jauges en BOLD NOIR + centrés verticalement.
> - L9 : texte court "xxxxxx" en Segoe UI Regular (au lieu de Light) ; badges Risque/Gain ET Parade/Levier en mode CAPSULE (`adjustments[0]=0.5`) ; lignes pointillées en `dash="sysDot"` (serrés) au lieu de `dash="dash"`.
> - L10 : bullet (cercle) + zone titre alignés au milieu verticalement (zone titre h=0,44 cm avec vertical_anchor MIDDLE).
> - Footer : numéro de slide + séparateur vertical + mention légale + classification posés explicitement par le générateur sur chaque slide.

> 🆕 **V2.2 (mai 2026)** — Trait sous titre repositionné au pixel près, take away remontée à y=16,65 cm, logo Safran à poser explicitement sur chaque slide, L7 chiffres KPI en couleur palette foncée par fond, L8 barres avec arrondi 30 %, L5 4ème puce uniformisée, L11 numéros filigrane corrigés (insertion solidFill en position 0 du rPr).

---

## Rappel : éléments présents sur TOUTES les slides (hérités du master OU posés par le générateur)

| Élément | Position (cm) | Taille (cm) | Détail |
|---|---|---|---|
| Fond | (0 ; 0) | 33,87 × 19,05 | `#FFFFFF` (sauf L9 = `#EFF1F6`) |
| Zone titre | (1,09 ; 0,71) | 31,70 × 1,58 | **Segoe UI Black** 29,32 pt non bold, `#484C6A`, aligné gauche |
| **Trait — rect épais (V2.2)** | **(1,093 ; 2,461)** | **1,867 × 0,267** | Rectangle plein `#484C6A`, noLine — issu du groupe master "Groupe 14" après transformation chOff/chExt |
| **Trait — ligne fine (V2.2)** | **départ (1,093 ; 2,707)** | **longueur 3,687, h=0** | Connecteur `line`, `#112753` (accent2 du thème), épaisseur 1 pt (12700 EMU) |
| **Barre Take away (V2.2)** | **(1,09 ; 16,65)** | 31,70 × 1,10 | Gradient `#A25871` avec shades 30%/67,5%/100%, noLine — **absente sur L5, L9 ; remplacée sur L11**. Y remontée de 0,22 cm vs template (16,87 → 16,65) pour libérer la zone du logo (marge 0,16 cm avant top logo). |
| Texte "Take away" | dans barre | — | 15,99 pt bold blanc, centré H+V |
| **Classification (V2.3)** | **(15,65 ; 0,18)** | **2,64 × 0,42** | "C2 - Confidential" Segoe UI 10 pt **`#FDA85B`** (orange thème), centré — **À poser explicitement sur CHAQUE slide via `add_classification(slide)`** |
| **Logo Safran (V2.2)** | **(29,77 ; 17,91)** | **3,03 × 0,64** | **À poser explicitement sur CHAQUE slide via `slide.shapes.add_picture('assets/logos/safran_logo.png', ...)` puis `kill_effects()`** |
| **N° de slide (V2.3)** | **(1,04 ; 18,53)** | **0,40 × 0,40** | **À poser explicitement** : Segoe UI 6 pt `#7D7B8D`, aligné gauche, vertical_anchor MIDDLE, texte = numéro de slide auto-incrémenté à partir de 1 |
| **Séparateur vertical (V2.3)** | **(1,55 ; 18,55)** | **0,02 × 0,32** | **Nouveau V2.3** — petit trait vertical fin entre n° slide et mention légale, rectangle plein `#7D7B8D`, noLine |
| **Mention légale (V2.3)** | **(1,75 ; 18,51)** | **26,32 × 0,40** | **À poser explicitement** : Segoe UI 6 pt `#7D7B8D`, aligné gauche, vertical_anchor MIDDLE, texte = "This document and the information therein are the property of Safran. They must not be copied or communicated to a third party without the prior written authorization of Safran" |

> 🎯 **V2.3 — Workflow obligatoire pour chaque slide** : après création de la slide, appeler dans cet ordre :
> 1. `add_classification(slide)` — classification "C2 - Confidential" en haut
> 2. `add_safran_logo(slide)` — logo en bas-droit
> 3. `add_footer(slide, slide_number)` — n° slide + séparateur + mention légale en bas-gauche

---

## Layout 1 — Hook factuel (manifesto + 3 KPI + 2 zones graphiques)

Slide d'ouverture impactante : un manifesto à gauche, 3 KPI alignés à droite, 2 zones graphiques en bas-centre, et la barre Take away en bas.

### Barre accent verticale (à gauche du manifesto)

| Élément | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) | Couleur |
|---|---|---|---|---|---|
| LeftAccentBar (rect) | 1,69 | 3,37 | 0,11 | 6,90 | `#A25871` |

### Manifesto (texte principal)

| Élément | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) | Style |
|---|---|---|---|---|---|
| Manifesto | 2,33 | 3,44 | 21,16 | 2,86 | Segoe UI Light **24 pt** couleur **`#474E67`**, **mots clés en bold NOIR `#000000`** (V2.3 — plus de couleurs palette), **interligne multiple 1,5** (`paragraph.line_spacing = 1.5`) |
| SubNarration | 2,33 | 7,96 | 20,46 | 2,82 | Segoe UI **13 pt** couleur **`#474E67`**, **mots clés en bold NOIR `#000000`** (V2.3), **interligne multiple 1,35** (`paragraph.line_spacing = 1.35`) |

> Exemple visuel : "Mieux planifier nos achats pour **reprendre la main** sur la performance économique de nos projets." — "reprendre la main" en **bold NOIR** (V2.3).

### 3 KPI à droite (pattern répétable)

Chaque KPI est composé de 4 éléments. **Position x commune : 24,20 cm** ; **largeur commune : 9,45 cm**.

| KPI | y accent (cm) | y chiffre (cm) | y label (cm) | y sublabel (cm) | Couleur chiffre |
|---|---|---|---|---|---|
| KPI1 | 2,89 | 3,18 | 5,29 | 6,07 | `#6A5D79` |
| KPI2 | 7,48 | 7,76 | 9,88 | 10,65 | `#A25871` |
| KPI3 | 12,06 | 12,35 | 14,46 | 15,24 | `#FDA85B` |

| Élément | Hauteur (cm) | Style |
|---|---|---|
| KpiAccent (rect) | 0,07 (largeur 1,13) | Couleur du chiffre (barre fine en haut) |
| KpiVal (chiffre) | 2,12 | **Segoe UI Black 44 pt bold**, couleur du KPI |
| KpiLbl (label) | 0,78 | Segoe UI **13 pt bold**, **`#000000` NOIR** (V2.1 : était `#070E1D` puis `#474E67`) |
| KpiSub (sublabel) | 0,71 | Segoe UI **10 pt** non bold, **`#474E67`** (V2.3 : repassé en `#474E67` ; était NOIR en V2.1/V2.2) |

> Exemple : "260 M€" / "d'achats engagés par an" / "périmètre RTDI hors PCS"

### Zones graphiques (placeholders pour l'utilisateur)

| Zone | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) |
|---|---|---|---|---|
| Image gauche | 1,34 | 11,67 | 11,09 | 4,57 |
| Image droite | 12,14 | 11,67 | 11,35 | 4,57 |

> ⚠️ Ces zones sont des **placeholders** — l'utilisateur fournira ses propres graphes. Ne pas inventer de contenu fictif. Si pas d'image fournie, laisser un rectangle gris discret (`#EFF1F6`) avec mention "Graphique 1" / "Graphique 2".

---

## Layout 2 — Hook 3 cartes verticales

3 colonnes type "card" avec **barre verticale colorée à gauche** + **picto** + **titre couleur** + **corps**. Idéal pour 3 messages clés à fort impact.

### Structure des 3 cards

| # | x card (cm) | x barre (cm) | x picto (cm) | y card (cm) | Largeur card (cm) | Hauteur card (cm) | Couleur barre |
|---|---|---|---|---|---|---|---|
| 1 | 2,11 | 1,69 | 2,36 | 4,71 | 9,64 | 8,11 | `#6A5D79` |
| 2 | 12,11 | 12,11 | 12,77 | 4,71 | 9,64 | 8,11 | `#A25871` |
| 3 | 22,53 | 22,53 | 23,19 | 4,71 | 9,64 | 8,11 | `#FDA85B` |

> ⚠️ La carte 1 n'a pas de roundRect blanc explicite dans l'audit — seule la barre est dessinée à gauche. Pour les cartes 2 et 3, un roundRect blanc 9,64×8,11 cm est posé en arrière-plan. **Recommandation** : poser un roundRect blanc pour les 3 cards par cohérence visuelle.

### Barre verticale colorée (par card)

```
Position : x=barre  y=4,71 cm  largeur=0,10 cm  hauteur=9,90 cm
Couleur  : couleur de la phase (#6A5D79 / #A25871 / #FDA85B)
```

### Picto (PNG 700×700 noir & blanc)

```
Position : x=picto  y=4,57 cm
Taille   : 2,0 × 2,0 cm
Source   : assets/pictos/picto_XX_*.png
```

### Titre de carte (petites majuscules avec première lettre capitale)

```
Position : x=picto  y=7,07 cm
Taille   : 9,0 × 2,66 cm
Style    : Segoe UI 20 pt bold, couleur de la barre
           Texte saisi en CASSE NORMALE (ex. "Le plan d'action doit vivre sur le terrain")
           + attribut cap="small" sur le run pour effet "petites majuscules avec 1ère lettre cap"
           ⚠ NE PAS saisir le texte en MAJUSCULES dures dans Python (text.upper())
```

### Corps de carte

```
Position : x=picto  y=11,35 cm
Taille   : 9,0 × 3,13 cm
Style    : Segoe UI Light 14 pt non bold, couleur #474E67
           Interligne multiple 1,3 (paragraph.line_spacing = 1.3)
```

---

## Layout 3 — Liste 6 points (6 teardrops)

Grille 3×2 de teardrops colorés avec label "FACTEUR xxx" sous chaque.

### Positions des 6 teardrops (forme OOXML native `teardrop`)

| # | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) | Couleur fond |
|---|---|---|---|---|---|
| 1 haut-g | 3,68 | 4,10 | 2,43 | 2,40 | `#BABDD0` (lavande) |
| 2 haut-m | 15,40 | 4,10 | 2,43 | 2,40 | `#BBB4C4` (violet pâle) |
| 3 haut-d | 27,11 | 4,10 | 2,43 | 2,40 | `#D5B3BE` (rose poudré) |
| 4 bas-g | 3,68 | 11,53 | 2,43 | 2,40 | `#F1D3D5` (rose pâle) |
| 5 bas-m | 15,33 | 11,36 | 2,43 | 2,40 | `#FEE3CA` (beige pêche) |
| 6 bas-d | 26,81 | 11,36 | 2,43 | 2,40 | `#FEF4DA` (jaune pâle) |

### Labels texte (sous chaque teardrop)

| # | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) |
|---|---|---|---|---|
| 1 | 1,43 | 6,89 | 6,94 | 0,85 |
| 2 | 13,36 | 6,95 | 6,94 | 0,85 |
| 3 | 24,86 | 6,95 | 6,94 | 0,85 |
| 4 | 1,47 | 14,21 | 6,94 | 0,85 |
| 5 | 13,20 | 14,21 | 6,94 | 0,85 |
| 6 | 24,56 | 14,21 | 6,94 | 0,85 |

**Style des labels** : run mixte = **"Facteur"** Segoe UI 14 pt **bold** avec **`cap="small"`** (petites majuscules avec 1ère lettre capitale) **+ " " + "xxxxx"** Segoe UI 14 pt non bold casse normale, centré, couleur **`#000000`**.

> ⚠️ **Important** : saisir "Facteur" en CASSE NORMALE puis injecter `cap="small"` dans le `<a:rPr>` du run, **PAS "FACTEUR" en MAJUSCULES dures**. Cela permet à PowerPoint d'afficher l'effet petites majuscules tout en gardant le texte modifiable proprement.

---

## Layout 4 — Triptyque (triangle de 3 anneaux)

Ce layout utilise des formes libres (`custGeom`) — anneaux colorés reliés par des barres courbes épaisses, avec des arcs décoratifs et petits points aux extrémités. Ces formes ne sont pas simples à reproduire en python-pptx.

**Stratégie recommandée** : insérer l'image rastérisée `assets/backgrounds/triangle_bg.png` (triangle complet SANS pictos) et superposer **uniquement les labels** (les pictos sont déjà dans l'image).

### Positionnement de l'asset `triangle_bg.png`

```
Image : assets/backgrounds/triangle_bg.png
Position : (9,50 ; 3,19) cm
Taille : 15,99 × 13,11 cm
```

### Centres des 3 anneaux (référentiel pour les pictos si insertion individuelle)

| Nœud | Centre (x, y) cm | Couleur anneau |
|---|---|---|
| Haut | (16,74 ; 6,18) | `#BBB4C4` (violet pâle) |
| Bas-gauche | (12,38 ; 13,38) | `#D5B3BE` (rose poudré) |
| Bas-droite | (21,41 ; 13,36) | `#FEE3CA` (beige pêche) |

### Labels (textes "xxx / xxx" à côté de chaque anneau)

| Label | Position (cm) | Taille (cm) | Notes |
|---|---|---|---|
| Au-dessus anneau haut | (17,41 ; 1,78) | 6,08 × 1,62 | Aligné à gauche |
| À droite anneau bas-droite | (25,24 ; 12,69) | 6,08 × 1,62 | Aligné à gauche |
| À gauche anneau bas-gauche | (1,96 ; 12,69) | 6,08 × 1,62 | Aligné à droite |

**Format texte de chaque label** :
- **1ère ligne** (titre) : Segoe UI **18 pt bold NOIR `#000000`** (V2.1 : était 14 pt)
- **2e ligne** (sous-titre) : Segoe UI **14 pt** non bold `#474E67` (V2.1 : était 10 pt et `#7D7B8D`)

---

## Layout 5 — Timeline 4 phases (ligne horizontale + cercles + textes)

Frise temporelle avec 4 étapes, chaque étape composée d'un petit point + ligne fine + cercle numéroté + textes étape.

> ⚠️ **Pas de barre Take away** sur ce layout.

### Structure d'une étape (4 étapes au total)

Soit `X` la position x de l'étape. Les Y sont **constants** sur toutes les étapes.

| Élément | Position relative | Taille | Style |
|---|---|---|---|
| Petit cercle plein (ellipse) | (X ; 6,72) | 0,42 × 0,42 cm | Couleur foncée de la phase, noLine |
| Ligne horizontale (rect) | (X+0,42 ; 6,91) | 6,83 × 0,05 cm | Couleur claire de la phase |
| Gros cercle numéroté (ellipse) | (X ; 7,64) | 0,92 × 0,92 cm | Couleur foncée de la phase, noLine |
| Numéro (texte dans cercle) | inscrit | — | Segoe UI **12 pt bold blanc**, centré H+V |
| Période ("T1 — AVR ›...") | (X ; 8,87) | 7,47 × 0,62 cm | Segoe UI **12 pt bold**, couleur foncée de la phase |
| Titre étape ("Cadrage") | (X ; 9,60) | 7,47 × 0,80 cm | Segoe UI **15 pt bold**, **`#000000` NOIR** (V2.1 : était 16 pt `#2D2D3D`/`#474E67`) |
| Description | (X ; 10,54) | 7,47 × 1,26+ cm | Segoe UI Light 12 pt couleur `#474E67`, interligne 1,3 |

### Positions x des 4 étapes et couleurs

| Étape | x (cm) | Couleur foncée (point + cercle + période) | Couleur claire (ligne) |
|---|---|---|---|
| 1 | 1,69 | `#6A5D79` | `#BBB4C4` |
| 2 | 9,44 | `#A25871` | `#D5B3BE` |
| 3 | 17,18 | `#D4737A` | `#F1D3D5` |
| 4 | 24,92 | `#FDA85B` | **`#FEE3CA`** (V2.3 — ajout d'une ligne après la 4ème puce, voir ci-dessous) |

### 🆕 V2.3 — Ligne horizontale APRÈS la 4ème puce

Pour assurer la cohérence visuelle avec les 3 autres puces (chacune ayant une ligne fine après son petit cercle), **ajouter une 4ème ligne horizontale après le petit cercle de la phase 4** :

```
Position : (X4 + 0,42 ; 6,91) cm = (25,34 ; 6,91)
Taille   : 6,83 × 0,05 cm
Fill     : #FEE3CA (couleur claire de la phase 4)
Line     : noLine
```

> ⚠️ **V2.3** : la ligne dépasse à droite (jusqu'à 32,17 cm) mais c'est l'effet voulu — elle se prolonge jusqu'au bord visuel droit de la slide, comme prolongation symbolique de la timeline.

> ⚠️ **L'étape 4 n'a pas de petit cercle initial** dans certaines variantes (audit OOXML ne montre que le gros cercle pour l'étape 4) — vérifier visuellement, mais par cohérence on recommande de mettre les 2 cercles pour les 4 étapes.

> Description peut s'étirer en hauteur (jusqu'à 1,93 cm pour l'étape 2 dans l'audit).

---

## Layout 6 — Tableau 5 colonnes

Tableau présenté dans un **conteneur roundRect blanc**, avec une rangée d'en-tête entièrement violette, puis 4 rangées de données alternées.

### Conteneur du tableau

```
RoundRect blanc :  (1,08 ; 4,94) cm  31,70 × 6,95 cm
Fill = #FFFFFF
```

### Ligne d'en-tête (rangée violette)

**Position y : 4,94 cm — Hauteur : 1,29 cm**

| Colonne | x (cm) | Largeur (cm) | x texte (cm) | Largeur texte (cm) |
|---|---|---|---|---|
| 1 — SEGMENT | 1,08 | 10,07 | 1,52 | 9,49 |
| 2 — ENGAGÉ 2024 | 11,15 | 5,79 | 11,59 | 5,08 |
| 3 — CIBLE 2025 | 16,94 | 4,88 | 17,38 | 4,15 |
| 4 — ÉCART PROJETÉ | 21,82 | 6,44 | 22,26 | 5,75 |
| 5 — PRIORITÉ | 28,26 | 4,53 | 28,70 | 3,79 |

**Fond de chaque cellule en-tête** : `#6A5D79` (couleur unique, pas de variation).
**Style texte en-tête** : Segoe UI **16 pt bold blanc `#FFFFFF`**, en MAJUSCULES VISUELLES.

### Rangées de données (4 rangées)

**Hauteurs alternées** :
- Rangée 1 : y=6,56 → ligne sép. à y=7,61 (h=0,02 cm `#D8DBE8`)
- Rangée 2 : y=7,96 (fond `#F4F5F9`, h=1,41 cm) → ligne sép. à y=9,03
- Rangée 3 : y=9,38 → ligne sép. à y=10,44
- Rangée 4 : y=10,79 (fond `#F4F5F9`, h=1,41 cm) → ligne sép. à y=11,86

| Rangée | Fond | y texte (cm) |
|---|---|---|
| 1 | blanc | 6,56 |
| 2 | `#F4F5F9` | 7,96 |
| 3 | blanc | 9,38 |
| 4 | `#F4F5F9` | 10,79 |

### Style des cellules

| Cellule | Style |
|---|---|
| Colonne 1 (titre rangée) | Segoe UI **14 pt bold**, **`#000000` NOIR** (V2.1 : était `#2D2D3D` / `#474E67`) |
| Colonnes 2, 3, 5 | Segoe UI 14 pt non bold, couleur `#474E67` |
| Colonne 4 ("écart") | Segoe UI **14 pt bold**, `#6A5D79` |
| Colonne 5 ("priorité") | Segoe UI **14 pt bold** (couleur hérité, peut être colorée selon valeur) |

---

## Layout 7 — Dashboard (6 KPI + séparateur "Texte" + 5 barres)

> 🆕 **V2.3 — CENTRAGE HORIZONTAL DU BLOC ENTIER** : tous les `x` ci-dessous sont **décalés de +0,315 cm** par rapport aux valeurs V2.2 pour symétrie gauche/droite dans la slide (largeur 33,87 cm). Le calcul : largeur du bloc visuel = 31,12 cm → marge = (33,87 − 31,12) / 2 = 1,375 cm.

### Partie haute — 6 tuiles KPI roundRect (y=3,70 cm, hauteur 4,44 cm)

| KPI | x (cm) — V2.3 | Largeur (cm) | Couleur fond | Couleur chiffre |
|---|---|---|---|---|
| KPI1 | **1,375** | 5,00 | `#BABDD0` | `#484C6A` |
| KPI2 | **6,605** | 5,00 | `#BBB4C4` | `#6A5D79` |
| KPI3 | **11,825** | 5,00 | `#D5B3BE` | `#A25871` |
| KPI4 | **17,045** | 5,00 | `#F1D3D5` | `#D4737A` |
| KPI5 | **22,265** | 5,00 | `#FEE3CA` | `#FDA85B` |
| KPI6 | **27,495** | 5,00 | `#FEF4DA` | `#FBCC58` |

> 🎯 **V2.2 — Couleur du chiffre 36 pt = couleur foncée de la palette associée au fond de la tuile (PAS `#474E67` uniformément)**. Chaque KPI a sa couleur dédiée — voir colonne "Couleur chiffre" ci-dessus.

**Contenu** :
- Chiffre/label principal : **Segoe UI 36 pt bold, couleur "chiffre" du tableau ci-dessus**, centré
- Sous-label "xxx" : Segoe UI 11 pt non bold, **`#474E67`** (= `dk2` thème), centré

### Séparateur "Texte" (au milieu de la slide)

```
Rectangle :   (1,395 ; 8,50) cm  31,08 × 1,17 cm    ← V2.3 : x recentré (anciennement 1,09)
Fill = #F4F5F9 (gris très clair, hérité)
Texte = "Texte" Segoe UI 12 pt bold italique, centré H+V
```

### Partie basse — 5 barres de progression

| # | y label (cm) | y track (cm) | Couleur fill barre |
|---|---|---|---|
| 1 | 10,28 | 10,28 | `#6A5D79` |
| 2 | 11,53 | 11,53 | `#A25871` |
| 3 | 12,78 | 12,78 | `#D4737A` |
| 4 | 14,04 | 14,04 | `#FDA85B` |
| 5 | 15,29 | 15,29 | `#FBCC58` |

> 🆕 **V2.3 — Y_label = Y_track** (et non plus 10,09 / 11,40 / ...) : la zone label gauche a maintenant la **même Y et même hauteur que la barre** (h=0,78 cm) avec `vertical_anchor = MSO_ANCHOR.MIDDLE` pour centrer le texte verticalement. Cela aligne visuellement le texte avec le centre vertical de la barre.

**Structure de chaque barre — V2.3** :
- **Label gauche** : "xxx" Segoe UI 11 pt **BOLD** (V2.3 : passé en bold) **couleur `#000000` NOIR**, **x=1,375 cm** (V2.3 : recentré), **largeur 6,94 cm**, **hauteur 0,78 cm** (V2.3 : égale à la barre, et non plus 0,97), **vertical_anchor = MIDDLE** (V2.3)
- **Track (fond barre)** : `roundRect` en mode CAPSULE (`adjustments[0] = 0.5` → rayon = h/2 = 0,39 cm pour h=0,78), **x=8,605 cm** (V2.3 : recentré, anciennement 8,29), **largeur fixe 23,89 cm**, hauteur 0,78 cm, fond très clair (hérité)
- **Fill (valeur barre)** : `roundRect` en mode CAPSULE (`adjustments[0] = 0.5`), **même x=8,605 cm**, largeur **variable** (à calculer en fonction de la valeur, max=23,89), hauteur 0,78 cm, couleur fill

> ⚠️ **V2.1 — Extrémités arrondies obligatoires** : appliquer `bar.adjustments[0] = 0.5` sur les 5 tracks ET les 5 fills pour obtenir l'effet "pilule" avec extrémités semi-circulaires. Sans cette ligne, on obtient les coins légèrement arrondis par défaut, ce qui ne correspond pas au template.

> 🆕 **V2.3 — Pourquoi les labels en BOLD** : sur le template cible (image fournie par l'utilisateur), les libellés gauche des jauges (Études, Sous-traitance, IT, Logistique, Travaux) ressortent visuellement en gras. La V2.2 les avait posés en non bold, ce qui ne correspondait pas au template.

> Exemple d'audit : valeurs observées 21,02 / 16,72 / 13,14 / 21,02 / 16,72 cm.

---

## Layout 8 — Comparatif (barres bidirectionnelles)

### Titre secondaire (sous le titre principal)

```
Position : (1,08 ; 4,04) cm  31,70 × 0,97 cm
Style : Segoe UI Black 21,3 pt bold, #685D79
Texte : "Titre" (à personnaliser)
```

### Légende (en haut à droite, y=6,14-6,20 cm)

| Élément | x (cm) | y (cm) | Taille | Style |
|---|---|---|---|---|
| Carré rose (fond barre rose) | 20,83 | 6,20 | 0,78 × 0,78 cm | Fill `#D5B3BE` |
| Label | 21,81 | 6,14 | 5,56 × 0,89 cm | Segoe UI 10 pt |
| Carré beige (fond barre beige) | 27,50 | 6,20 | 0,78 × 0,78 cm | Fill `#FEE3CA` |
| Label | 28,47 | 6,14 | 5,56 × 0,89 cm | Segoe UI 10 pt |

### 5 rangées de comparaison

**Y des rangées** : 8,05 / 9,35 / 10,66 / 11,97 / 13,27 cm.

| Élément | x (cm) | Largeur (cm) | Hauteur (cm) | Style |
|---|---|---|---|---|
| Label gauche | 1,08 | 10,56 | 0,97 | Segoe UI **12 pt bold**, **`#000000` NOIR** (V2.1 : était `#333333` / `#474E67`), **aligné gauche** (`PP_ALIGN.LEFT`) |
| Barre rose (roundRect) | 11,94 | **variable** (4,89 à 12,22) | 0,83 | Fill `#D5B3BE`, **valeur 12 pt bold `#474E67` alignée droite** (V2.1 : était `#FFFFFF` blanc — passé en foncé pour lisibilité sur fond clair) |
| Barre beige (roundRect) | 24,44 | **variable** (2,44 à 7,33) | 0,83 | Fill `#FEE3CA`, **valeur 12 pt bold `#474E67` alignée droite** (V2.1 : était `#FFFFFF`) |

> Largeur min observée 2,44 cm (rangée 5), max 12,22 cm (rangée 1). Calculer la largeur en fonction de la valeur (proportionnelle).

---

## Layout 9 — Risques & Opportunités (6 cards 3×2 avec badges)

> ⚠️ **CARACTÉRISTIQUE UNIQUE** : ce layout a un **fond de slide entier `#EFF1F6`** (gris bleuté très clair), pas blanc. Et **PAS de barre Take away**.

### Fond du slide

```
Background : a:schemeClr val="accent3" → #EFF1F6
```

### Position des 6 cards (grille 3×2)

| Card | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) |
|---|---|---|---|---|
| 1 (haut-gauche) | 0,30 | 3,68 | 10,90 | 6,41 |
| 2 (haut-centre) | 11,45 | 3,68 | 10,90 | 6,41 |
| 3 (haut-droite) | 22,59 | 3,68 | 10,90 | 6,41 |
| 4 (bas-gauche) | 0,30 | 10,56 | 10,90 | 6,41 |
| 5 (bas-centre) | 11,45 | 10,56 | 10,90 | 6,41 |
| 6 (bas-droite) | 22,59 | 10,56 | 10,90 | 6,41 |

**Card** :
- `roundRect` blanc (`schemeClr bg1`)
- Bordure `ln w=3175` (≈0,01 cm) avec `tx2 lumMod=40000 lumOff=60000` (gris violet pâle)

### Structure interne d'une card (offsets relatifs à `X` et `Y` de la card)

#### Picto Wingdings (badge en haut-gauche)

```
RoundRect : (X+0,25 ; Y+0,50)  0,90 × 1,00 cm
  Fill = #BBB4C4 (haut, "risque") OU #FEF4DA (bas, "opportunité")
  Caractère : J = ☺ (smiley) pour opportunités  /  L = ☹ (frowny) pour risques
  Police = Wingdings (Symbol-style), bold, couleur dédiée :
    - Pour Risques : couleur texte = #6A5D79
    - Pour Opportunités : couleur texte = #FBCC58
```

> ⚠️ **Choix utilisateur confirmé** : garder la police Wingdings (risque de fallback hors Windows mais conforme au template original).

#### Titre de la card

```
Position : (X+1,32 ; Y+0,30) ; largeur 9,30 cm hauteur 0,77 cm
Style : Segoe UI 12 pt bold, COULEUR #000000 NOIR (V2.1 : était hérité gris)
Exemples : "Non-embarquement des parties prenantes" / "Accostage avec un projet en cours"
```

#### Badge risque/gain (à côté du titre)

```
RoundRect : (X+1,53 ; Y+1,07)  2,49 × 0,53 cm
              🆕 V2.3 — adjustments[0] = 0.5 (MODE CAPSULE, rayon = h/2 = 0,265 cm)
                       Avant V2.3 : arrondi par défaut (≈0,1) — non conforme au template
Style : Segoe UI 10 pt PETITES MAJUSCULES AVEC 1ÈRE LETTRE CAPITALE
        → texte saisi en CASSE NORMALE ("Risque élevé", "Risque moyen",
                                          "Gain élevé", "Gain moyen")
        → injecter cap="small" dans <a:rPr> du run
        ⚠ NE PAS saisir le texte en MAJUSCULES dures
Variantes :
  - Risque élevé  : fill #FF9797, texte #C00000
  - Risque moyen  : fill #FEE3CA, texte #FDA85B
  - Gain élevé    : fill #69FFAD, texte #00B050
  - Gain moyen    : fill #FFFF85, texte #A8A400
```

#### Texte sous le titre ("xxxxxx")

```
Position : (X+0,12 ; Y+1,92)  largeur ~8,81 cm hauteur 0,68 cm
Style : Segoe UI Regular (V2.3 — passé de Light à Regular) 10 pt non bold,
        COULEUR #000000 NOIR
        (V2.1 : était Calibri puis Segoe UI Light #474E67 puis NOIR — V2.3 : passé en REGULAR)
```

#### Ligne pointillée séparatrice (au milieu de la card)

```
Connecteur droit (line) : (X+0,27 ; Y+3,87)  10,37 × 0 cm
Style : ln avec dash="sysDot" (V2.3 — POINTILLÉS SERRÉS, anciennement "dash" tirets longs),
        couleur tx2 lumMod=20000 lumOff=80000 (gris très clair)
```

> 🆕 **V2.3 — `dash="sysDot"`** : produit des pointillés serrés rapprochés. Auparavant `dash="dash"` produisait des tirets longs espacés, ce qui ne correspondait pas au template cible.

#### Petit badge "Parade" / "Levier" (sous la ligne)

```
RoundRect : (X+0,25 ; Y+4,06)  1,71 × 0,53 cm
              🆕 V2.3 — adjustments[0] = 0.5 (MODE CAPSULE, rayon = h/2 = 0,265 cm)
Fill = #DDE7CF (vert pâle uniforme)
Texte = "Parade" / "Levier" Segoe UI 10 pt PETITES MAJUSCULES AVEC 1ÈRE LETTRE CAPITALE
        → texte saisi "Parade" / "Levier" + cap="small" dans <a:rPr>
Couleur texte : #8DAC95, centré
```

#### Texte explicatif "xxxxxxxx..." (long, sous le badge)

```
Position : (X+2,17 ; Y+4,06)  largeur ~8,81 cm hauteur 0,98 cm
Style : Segoe UI Light 10 pt non bold, COULEUR #000000 NOIR
        (V2.1 : était couleur accent6 hérité — désormais NOIR explicite)
        ⚠ V2.3 : ce texte RESTE en Segoe UI Light (seul le texte court "xxxxxx" du haut passe en Regular)
```

> **Convention métier** : les 3 cards du haut = **risques** (badge rouge/orange), les 3 cards du bas = **opportunités** (badge vert/jaune).

---

## Layout 10 — Plan d'action 3 phases (cards numérotées)

3 cards rectangulaires identiques avec bande header colorée, numéro Unicode ①②③, et 3 puces.

### Position des 3 cards

| Card | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) | Couleur phase |
|---|---|---|---|---|---|
| 1 | 0,61 | 4,10 | 10,50 | 11,49 | `#6A5D79` (audit OOXML — pas `#484C6A` comme dans l'ancien template) |
| 2 | 11,68 | 4,10 | 10,50 | 11,49 | `#A25871` |
| 3 | 22,86 | 4,10 | 10,50 | 11,49 | `#FDA85B` |

> ⚠️ **Note importante** : la couleur de la card 1 dans le **nouveau template** est `#6A5D79` (violet grisé), à confirmer. L'audit OOXML montre une bordure `ln w=19050 #6A5D79` mais le rendu visuel ressemble à du `#484C6A`. Dans le doute, **utiliser la couleur de la bordure mesurée** = `#6A5D79`.

### Structure d'une card (offsets relatifs à `X` et `Y`)

#### Fond + bordure
```
Rectangle plein :  (X ; Y) 10,50 × 11,49 cm
Fill = #FFFFFF
Line = ln w=19050 (1,5 pt) couleur_phase
```

#### Bande header
```
Rectangle plein :  (X ; Y) 10,50 × 2,10 cm
Fill = couleur_phase
Line = ln w=12700 (1 pt) même couleur_phase OU #484C6A pour la card 1
```

#### Numéro ①②③ (Unicode)
```
Texte :      (X+0,17 ; Y+0,20) 1,42 × 1,42 cm
Caractère :  ① / ② / ③ (Unicode U+2460 / U+2461 / U+2462)
Style :      24 pt bold blanc #FFFFFF, centré H+V
```

#### Titres de bande
```
Titre principal :  (X+1,76 ; Y+0,23) 8,40 × 0,95 cm  → "Titre N"  16 pt bold blanc
Sous-titre      :  (X+1,76 ; Y+1,15) 8,40 × 0,81 cm  → "Titre N"  12 pt non bold blanc (italique optionnel)
```

#### Les 3 puces — positions absolues Y (V2.3)

> 🆕 **V2.3 — ALIGNEMENT VERTICAL CENTRÉ ENTRE BULLET ET TITRE** : pour chaque puce, le **centre Y du cercle plein doit être identique au centre Y de la zone titre**. Implémentation : la zone titre passe à **hauteur 0,44 cm** (égale au cercle) avec **`vertical_anchor = MSO_ANCHOR.MIDDLE`**. Y_cercle = Y_titre.

| # | Y cercle = Y titre (cm) | Y corps (cm) | Y ligne sép. (cm) |
|---|---|---|---|
| Puce 1 | **6,59** | 7,26 | 8,91 (après puce 1) |
| Puce 2 | **9,36** | 10,04–10,41 | 12,05 (après puce 2) |
| Puce 3 | **12,51** | 13,18–13,36 | — |

#### Structure d'une puce — V2.3

```
Petit cercle plein (ellipse) :   (X+0,30 ; Y_cercle) 0,44 × 0,44 cm
  Fill = couleur_phase, noLine

Titre de puce (zone texte) :     (X+1,02 ; Y_cercle) 9,08 × 0,44 cm   🆕 V2.3 : h=0,44 (= cercle)
  Style = Segoe UI 11 pt bold, COULEUR #000000 NOIR
          vertical_anchor = MSO_ANCHOR.MIDDLE   🆕 V2.3 (centrer texte verticalement)
          (V2.1 : h=1,02 ; V2.3 : h=0,44 pour aligner centre Y avec le cercle)

Corps de puce (zone texte) :     (X+1,02 ; Y_corps) 9,08 × 0,85 cm
  Style = Segoe UI Light 10,5 pt non bold, COULEUR #474E67
          (V2.1 : était #4A4A6A — couleur dk2 du thème)
```

> 🎯 **V2.3 — Effet visuel attendu** : le cercle plein de 0,44 cm et le texte "Diagnostic du périmètre" / "Bascule par segment" / "Bilan d'efficacité" sont **alignés sur leur centre vertical**, comme deux objets posés sur la même ligne médiane horizontale. C'est le comportement attendu d'une puce visuelle classique (bullet + texte sur même baseline).

#### Lignes séparatrices entre puces
```
Ligne horizontale : (X+0,30 ; Y_sep) 9,65 × 0 cm (line shape)
Style = ln w=6350 (0,5 pt) #E0E0E8
```

> *(la valeur `0,30` pour l'offset X du cercle et des séparatrices est mesurée — voir audit. Les cards 2 et 3 utilisent une valeur légèrement différente (0,41/0,27) ; utiliser **0,30** par convention)*

---

## Layout 11 — Arc narratif et CTA

3 blocs verticaux avec **barre accent gauche** + **numéro fantôme géant en arrière-plan** + **titre coloré** + **corps**, plus un **CTA personnalisé** en bas (remplace la barre Take away classique).

### Structure des 3 blocs

| Bloc | y barre/numéro (cm) | Couleur barre (foncée) | Couleur numéro fantôme (claire) |
|---|---|---|---|
| 1 | 3,20 / 3,05 | `#6A5D79` | `#BBB4C4` |
| 2 | 7,70 / 7,55 | `#A25871` | `#D5B3BE` |
| 3 | 12,20 / 12,05 | `#FDA85B` | `#FEE3CA` |

### Éléments de chaque bloc

| Élément | x (cm) | y (cm) | Largeur (cm) | Hauteur (cm) | Style |
|---|---|---|---|---|---|
| AccentBar (roundRect) | 1,09 | bloc | 0,18 | 3,80 | Couleur foncée de la phase, noLine |
| Num "01"/"02"/"03" | 1,80 | bloc-0,15 | 3,00–3,83 | 3,80 | **Segoe UI Black 71,99 pt bold**, couleur claire de la phase **avec `<a:alpha val="40000"/>` (= 40 % d'opacité = 60 % de transparence)** pour effet filigrane |
| BlockTitle | 2,00 | bloc+0,25 | 29,50 | 1,10 | Segoe UI bold, couleur foncée de la phase |
| BlockBody | 2,00 | bloc+1,45 | 29,50 | 2,40 | Segoe UI Light **14 pt** non bold, couleur `#474E67`, mots clés en bold |

> **🎯 Z-ORDER OBLIGATOIRE (V2.1)** : le numéro fantôme est posé **en arrière-plan** dans le `spTree`. Procédure :
> 1. Créer le textbox du numéro
> 2. Récupérer son élément XML : `num_xml = num_textbox._element`
> 3. Récupérer le parent `spTree` : `spTree = num_xml.getparent()`
> 4. Le retirer : `spTree.remove(num_xml)`
> 5. Le réinsérer en position 2 (juste après `nvGrpSpPr` et `grpSpPr`, avant tous les autres shapes) : `spTree.insert(2, num_xml)`
>
> **Effet visuel attendu** : chiffre énorme et pâle EN FILIGRANE DERRIÈRE le titre du bloc (le titre passe par-dessus). Sans le placement en arrière-plan, le filigrane recouvre le titre, ce qui est INCORRECT.

> Largeur du numéro fantôme : 3,00 cm pour "01", 3,39 cm pour "02", 3,83 cm pour "03" (correspond à la largeur visuelle du chiffre rendu en 72 pt — ne pas s'inquiéter du chevauchement, c'est un effet voulu).

### CTA en bas (remplace la barre Take away)

```
Rectangle :  (1,09 ; 16,65) cm  31,70 × 1,10 cm    ← V2.2 : remontée de 0,22 cm comme la barre Take away standard
Fill = gradient identique à Take away (#A25871 avec shades 30/67,5/100)
Line = noLine
Texte : Segoe UI 16 pt bold blanc, centré H+V
        (Texte personnalisé, peut être plus long et tenir sur 2 lignes si nécessaire)
```

> Exemple : "Êtes-vous prêts à sponsoriser le sujet « connexion ERP – systèmes locaux » et à mandater une équipe pour l'instruire ?"

---

## Notes finales sur la reproduction

- **L4** : la reproduction exacte des formes libres (`custGeom`) est trop coûteuse en code ; utiliser l'asset rastérisé `triangle_bg.png` est la bonne stratégie, au prix d'une image non éditable dans PowerPoint (mais visuellement identique).
- **Gradient Take away** : python-pptx n'expose pas nativement l'attribut `shade` d'un `srgbClr`. Il faut manipuler le XML directement après création de la forme (méthode : récupérer `shape._element`, créer/remplacer `<a:gradFill>`).
- **Wingdings (L9)** : prévoir un fallback PNG si le déploiement cible n'a pas la police (visible sur LibreOffice, certains macOS, mobile). L'utilisateur a confirmé qu'il accepte le risque.
- **L1 zones d'image** : ce sont des placeholders. Si l'utilisateur ne fournit pas d'images, poser un rectangle gris discret (`#EFF1F6`) avec un label "Graphique 1 / 2" en gris moyen.
- **L9 fond slide** : se définit en éditant le `<p:bg>` du XML de la slide directement, ou via `slide.background.fill.solid()` puis `fore_color.rgb = RGBColor(0xEF, 0xF1, 0xF6)`.
