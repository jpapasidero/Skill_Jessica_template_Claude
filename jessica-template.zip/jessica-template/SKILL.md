---
name: jessica-template
description: >
  Utilisez ce skill OBLIGATOIREMENT chaque fois que vous créez, modifiez ou générez une présentation PowerPoint (.pptx) pour Safran ou que l'utilisateur mentionne le template "Jessica", "Palette Jessica", ou toute référence à une présentation Safran. Ce skill garantit que chaque slide générée correspond **pixel pour pixel** au template officiel Safran "Palette Jessica" — couleurs exactes, typographie, positions, layouts et assets. Ne jamais créer une présentation sans ce skill si le contexte est Safran ou si le template Jessica est mentionné, même implicitement.
---

# Skill — Template Safran "Palette Jessica" (Pixel-Perfect, V2.3 — 11 layouts)

Ce skill doit être suivi **à la lettre** pour toute présentation Safran. Chaque écart de couleur, police ou position sera visible et non acceptable.

**Toutes les valeurs de ce document sont issues d'un audit OOXML direct du fichier `Template_Palette_Jessica.pptx`** (unpack + mesure des `<a:off>`/`<a:ext>` en EMU → cm, extraction des `<a:srgbClr>` et `<a:gradFill>`).

> 🆕 **V2.3 (mai 2026)** — Corrections issues d'annotations manuscrites sur impression du test V2.2 (layouts L1/L5/L7/L9/L10 + footer commun) :
> - **L1** — Mots clés en emphase dans le manifesto → **bold NOIR `#000000`** (au lieu de bold couleur palette `#A25871`/`#6A5D79`).
> - **L1** — Sous-labels des 3 KPI (côté droit) → **`#474E67`** (au lieu de NOIR `#000000` posé en V2.1).
> - **L5** — Ajout d'une **ligne horizontale `#FEE3CA`** (couleur claire de la phase 4) après la 4ème puce de timeline, par cohérence visuelle avec les 3 autres puces.
> - **L7** — Le bloc complet (6 KPI + séparateur + 5 jauges) doit être **centré horizontalement** dans la slide (offset commun calculé pour symétrie gauche/droite).
> - **L7** — Labels gauche des 5 jauges (Études, Sous-traitance, IT, Logistique, Travaux) : **bold NOIR** (au lieu de non bold) ET **centrés verticalement** sur leur barre respective (baseline au milieu de la barre h=0,78 cm).
> - **L9** — Textes courts sous titres de cards passent de **Segoe UI Light → Segoe UI Regular** (police plus marquée pour ces 6 textes courts).
> - **L9** — Badges risque/gain (Risque élevé/moyen, Gain élevé/moyen) en **mode CAPSULE** (`adjustments[0] = 0.5`) au lieu de l'arrondi par défaut.
> - **L9** — Lignes pointillées séparatrices au milieu des cards : **pointillés plus serrés** (`dash="sysDot"` au lieu de `dash="dash"`).
> - **L10** — Bullet (cercle plein 0,44 cm) + titre noir bold de chaque puce : **alignés au milieu verticalement entre eux** (centre Y du cercle = centre Y de la zone titre).
> - **TOUTES SLIDES** — Le générateur Python pose explicitement sur chaque slide : **mention légale** en bas (Segoe UI 6 pt `#7D7B8D`), **numéro de slide** (placeholder), **séparateur vertical fin** entre les deux. Ces 3 éléments sont hérités du master mais l'expérience montre qu'ils n'apparaissent pas toujours selon le master du fichier de sortie — donc on les pose explicitement.

> 🆕 **V2.2 (mai 2026)** — Corrections pixel-perfect issues d'un re-audit OOXML du master du template :
> - **Trait sous titre** repositionné au pixel près : rect épais (1,093 ; 2,461) 1,867×0,267 ; ligne fine départ (1,093 ; 2,707) longueur 3,687.
> - **Logo Safran** désormais posé sur **chaque slide** par le générateur (le master du test est vide, donc l'héritage ne suffit pas) : (29,77 ; 17,91) 3,03×0,64 cm — `assets/logos/safran_logo.png`.
> - **Barre Take away remontée à y=16,65 cm** (au lieu de 16,87) pour libérer la zone du logo (marge 0,16 cm avant le top du logo).
> - **L7** chiffres KPI 36 pt : la couleur n'est plus uniformément `#474E67` mais la **couleur foncée de la palette associée au fond** (mapping fond→texte ci-dessous).
> - **L8** jauges roundRect : ajout de l'arrondi modéré `adjustments[0]=0.3` (≠ capsule du L7) pour reproduire le `gd fmla="val 30000"` du template.
> - **L11** numéros filigrane : correction de l'injection alpha → le `<a:solidFill>` doit être inséré **en première position du `<a:rPr>`** (avant `<a:latin>`), sinon PowerPoint l'ignore et le numéro apparaît noir.
> - **L5** : harmonisation de la 4ème puce de timeline (titre 15 pt noir, description 12 pt `#474E67` — comme les 3 autres puces).

> 🆕 **V2.1 (mai 2026)** — Ajustements typographiques et chromatiques par layout : nombreux passages au noir `#000000` (labels KPI L1, titre étape L5, 1ère colonne L6, labels L8, titres+corps L9, titres puces L10), petites majuscules avec 1ère lettre cap pour L2/L3/L9, interlignes manifesto L1 (1,5) et corps L2 (1,3), tailles +18 pt L4, jauges L7 en capsule (`adjustments[0]=0.5`), valeurs L8 en `#474E67` (PAS blanc), numéros L11 en arrière-plan (z-order spTree.insert(2)).

> ⚠️ **CONTRAINTE STRICTE** : ce skill définit **exactement 11 layouts** (L1 à L11). N'utiliser **aucun autre layout** que ceux documentés ici. Toute slide doit correspondre à l'un de ces 11 layouts.

---

## 1. Format de slide (OBLIGATOIRE)

```
Dimensions : 33,87 × 19,05 cm (1280 × 720 px @ 96 dpi)
Format     : 16:9 widescreen
EMU        : 12 192 000 × 6 858 000
Fond       : #FFFFFF blanc pur (sauf L9 = #EFF1F6)
```

---

## 1.bis 🚫 SUPPRESSION DES OMBRES (CRITIQUE — à appliquer sur TOUTES les formes)

⚠️ **Le thème "Palette Jessica" applique par défaut une ombre douce sur toutes les formes** (via `effectStyleLst` du thème). Sans intervention explicite, chaque rectangle/roundRect/ellipse hérite de cette ombre, ce qui casse le rendu pixel-perfect du template original.

### Action obligatoire pour chaque shape créée

Sur **chaque forme générée par python-pptx**, injecter dans le XML :

1. Un **`<a:effectLst/>` vide** dans le `spPr` (override pour PowerPoint Windows)
2. Un **`effectRef idx="0"`** dans le `<p:style>` (override pour LibreOffice / cross-renderer)

### Helper Python à utiliser systématiquement

```python
from pptx.oxml.ns import qn
from lxml import etree

def kill_effects(shape):
    """À appeler après CHAQUE création de shape pour supprimer l'ombre du thème.
       Compatible PowerPoint Windows + LibreOffice + macOS."""
    spPr = shape._element.spPr
    # 1) effectLst vide dans spPr
    for el in spPr.findall(qn('a:effectLst')):
        spPr.remove(el)
    etree.SubElement(spPr, qn('a:effectLst'))
    # 2) Forcer effectRef idx=0 dans p:style si présent
    style = shape._element.find(qn('p:style'))
    if style is not None:
        effectRef = style.find(qn('a:effectRef'))
        if effectRef is not None:
            effectRef.set('idx', '0')
```

### Règle d'or

> **Aucune forme ne doit jamais quitter le générateur sans avoir été passée à `kill_effects()`.** Y compris : rectangles, roundRects, ellipses (teardrops, ovales), connecteurs, images, textboxes.

---

## 2. Palette de couleurs thème (extraite de `theme1.xml`)

| Rôle | HEX | Usage constaté |
|---|---|---|
| `dk1` | `#070E1D` | Texte sombre L1 (label KPI) |
| `lt1` | `#FFFFFF` | Fond slide, texte sur fond coloré |
| `dk2` | `#474E67` | Valeur thème — **non utilisée directement** : le `titleStyle` du master surcharge avec `#484C6A` |
| `lt2` | `#7D7B8D` | Texte corps des puces, mention légale |
| `accent1` | `#3B87CC` | Non utilisé |
| `accent2` | `#112753` | — |
| `accent3` | `#EFF1F6` | **Fond du slide L9 (Risques & Opportunités)** |

### Couleurs "Jessica" (utilisées dans les layouts)

| # | Nom | HEX | Usage principal dans les layouts |
|---|---|---|---|
| 1 | Bleu gris foncé | `#484C6A` | Titre principal (master) ; L2 carte 1 ; L6 header colonne ; L10 card 1 ; L11 timeline phase 1 |
| 2 | Lavande clair | `#BABDD0` | L7 KPI1 fond ; L9 badge Wingdings (carrés colorés) |
| 3 | Violet grisé | `#6A5D79` | L1 manifesto bold + KPI1 chiffre ; L2 carte 2 + barre ; L6 header tableau ; L7 KPI2 chiffre ; L11 phase 1 accent |
| 4 | Violet pâle | `#BBB4C4` | L4 anneau haut ; L7 KPI2 fond ; L9 badge ; L11 numéro fantôme phase 1 |
| 5 | Vieux rose foncé | `#A25871` | Gradient Take away ; L1 KPI2 chiffre + barre accent gauche ; L7 KPI3 chiffre ; L10 card 2 ; L11 phase 2 accent |
| 6 | Rose poudré | `#D5B3BE` | L4 anneau bas-gauche ; L7 KPI3 fond ; L8 barre rose + légende ; L11 numéro fantôme phase 2 |
| 7 | Rose corail | `#D4737A` | L5 timeline puce 3 ; L7 KPI4 chiffre |
| 8 | Rose très pâle | `#F1D3D5` | L7 KPI4 fond |
| 9 | Orange doux | `#FDA85B` | L1 KPI3 chiffre ; L2 carte 3 + barre ; L5 timeline puce 4 ; L7 KPI5 chiffre ; L10 card 3 ; L11 phase 3 accent |
| 10 | Beige pêche | `#FEE3CA` | L4 anneau bas-droite ; L7 KPI5 fond ; L8 barre beige + légende ; L9 badge "Risque moyen" ; L11 numéro fantôme phase 3 |
| 11 | Jaune moutarde | `#FBCC58` | L7 KPI6 chiffre |
| 12 | Jaune très pâle | `#FEF4DA` | L7 KPI6 fond ; L9 badge gain (jaune) |

### Couleurs utilitaires (utilisées dans un ou plusieurs layouts)

| HEX | Usage |
|---|---|
| `#FFFFFF` | Fond slide, intérieur cards L2/L10, texte sur fond coloré |
| **`#474E67`** | **🎯 COULEUR DE RÉFÉRENCE pour textes corps non-noirs** (= `dk2` du thème). À utiliser pour : manifesto L1, sous-narration L1, corps L2, sous-titre L4 (10 pt → 14 pt), description L5 (Light 12 pt), cellules colonnes 2-5 L6 (sauf en-tête et 1ère col), KPI text L7 (chiffres et sous-labels dans les tuiles), légende L8, **valeurs numériques dans barres L8 (PAS blanc)**, corps L11 (Light 14 pt), corps puces L10 (Light 10,5 pt). **Note** : les passages en NOIR (#000000) demandés par mise à jour V2.1 incluent désormais : labels et sous-labels KPI L1, titre étape L5, 1ère colonne L6, labels gauche L8, titres et corps L9, titres puces L10. |
| `#000000` | **NOIR** : Titres labels L4, "Facteur" L3, **séparateur "Texte" L7**, **labels gauche jauges L7**, **labels KPI + sous-labels L1 (côté droit, 13 pt + 10 pt)**, **titre étape L5 (15 pt)**, **1ère colonne tableau L6**, **labels gauche rangées L8 (12 pt bold)**, **titres cards L9 (12 pt bold)**, **corps Segoe UI Light L9 (10 pt)**, **titres puces L10 (11 pt bold)** |
| `#7D7B8D` | Mention légale uniquement (master) |
| `#E0E0E8` | Séparateurs horizontaux entre puces L10 (lignes 0,5 pt) |
| `#D8DBE8` | Bordures et séparateurs L6 (0,02 cm = 0,75 pt) |
| `#F4F5F9` | Fond des rangées paires du tableau L6 (alternance avec blanc) |
| `#EFF1F6` | **Fond du slide entier L9** (gris bleuté très clair) |
| `#DDE7CF` | Fond badge "Parade" / "Levier" L9 |
| `#8DAC95` | Texte "Parade" / "Levier" L9 |
| `#FF9797` | Fond badge "Risque élevé" L9 |
| `#C00000` | Texte "Risque élevé" L9 |
| `#69FFAD` | Fond badge "Gain élevé" L9 |
| `#00B050` | Texte "Gain élevé" L9 |
| `#FFFF85` | Fond badge "Gain moyen" L9 |
| `#A8A400` | Texte "Gain moyen" L9 |

> ⚠️ **Note sur les titres** : bien que `dk2` du thème vaille `#474E67`, le `titleStyle` du master **surcharge** cette valeur avec `#484C6A` explicitement (`<a:srgbClr val="484C6A">` dans `p:titleStyle/a:lvl1pPr/a:defRPr`). **Utiliser strictement `#484C6A` pour tous les titres principaux de slide.**

---

## 3. Typographie (référencée par layout)

### 3.1 Typographie commune (master)

| Usage | Police | Taille | Bold | Couleur |
|---|---|---|---|---|
| **Titre principal** | **Segoe UI Black** | **29,32 pt** | non | **`#484C6A`** |
| **Barre "Take away"** | Segoe UI | **15,99 pt** | **oui** | `#FFFFFF` (centré H+V) |

### 3.2 Typographie par layout (synthèse)

| Layout | Élément | Police | Taille | Bold | Couleur |
|---|---|---|---|---|---|
| **L1** | Manifesto principal | Segoe UI Light | 24 pt | non | **`#474E67`** (mots clés en **bold NOIR `#000000`** — V2.3, plus de couleurs palette), **interligne 1,5** |
| **L1** | Sous-narration | Segoe UI | 13 pt | non | **`#474E67`**, **interligne 1,35** |
| **L1** | Chiffre KPI | **Segoe UI Black** | 44 pt | **oui** | couleur palette KPI (`#6A5D79`/`#A25871`/`#FDA85B`) |
| **L1** | Label KPI | Segoe UI | 13 pt | **oui** | **`#000000` noir** |
| **L1** | Sous-label KPI | Segoe UI | 10 pt | non | **`#474E67`** (V2.3 : était NOIR en V2.1, repassé en `#474E67`) |
| **L2** | Titre de carte | Segoe UI | 20 pt | **oui** | couleur de la barre (`#6A5D79`/`#A25871`/`#FDA85B`), **petites majuscules avec première lettre capitale** (`smallCaps` + texte saisi en casse normale type "Le plan d'action…") |
| **L2** | Corps de carte | Segoe UI Light | 14 pt | non | **`#474E67`**, **interligne 1,3** |
| **L3** | "Facteur" (premier mot) | Segoe UI | 14 pt | **oui** | **petites majuscules avec première lettre capitale** (`smallCaps` + texte saisi "Facteur"), `#000000` |
| **L3** | "xxxxx" (suite du label) | Segoe UI | 14 pt | non | `#000000`, normal (run mixte avec le premier mot) |
| **L4** | Titre de label (1re ligne) | Segoe UI | **18 pt** | **oui** | **`#000000` noir** |
| **L4** | Sous-titre de label (2e ligne) | Segoe UI | **14 pt** | non | **`#474E67`** |
| **L5** | Numéro étape (cercle) | Segoe UI | 12 pt | **oui** | `#FFFFFF` |
| **L5** | Période "T1 — AVR ›..." | Segoe UI | 12 pt | **oui** | couleur de la phase |
| **L5** | Titre étape ("Cadrage"...) | Segoe UI | **15 pt** | **oui** | **`#000000` noir** |
| **L5** | Description étape | Segoe UI Light | 12 pt | non | **`#474E67`**, **interligne 1,3** |
| **L6** | En-tête de colonne | Segoe UI | 16 pt | **oui** | `#FFFFFF`, centré |
| **L6** | Cellule 1ère colonne | Segoe UI | 14 pt | **oui** | **`#000000` noir** |
| **L6** | Cellule autres colonnes | Segoe UI | 14 pt | non | **`#474E67`** |
| **L6** | Cellule "écart" | Segoe UI | 14 pt | **oui** | `#6A5D79` |
| **L7** | Chiffre KPI | Segoe UI | 36 pt | **oui** | **couleur PALETTE FONCÉE associée au fond du KPI** (V2.2) — voir mapping ci-dessous |
| **L7** | Sous-label KPI | Segoe UI | 11 pt | non | **`#474E67`** |
| **L7** | Texte central séparateur ("Texte"/"Performance...") | Segoe UI | 12 pt | **oui** | **`#000000` noir** (italique optionnel) |
| **L7** | Label barre de progression (gauche) | Segoe UI | 11 pt | **oui** | **`#000000` noir**, **centré verticalement sur la barre** (V2.3) |
| **L8** | Titre secondaire | **Segoe UI Black** | 21,3 pt | **oui** | `#685D79` |
| **L8** | Label de rangée (gauche) | Segoe UI | 12 pt | **oui** | **`#000000` noir**, **aligné gauche** |
| **L8** | Valeur sur barre | Segoe UI | 12 pt | **oui** | **`#474E67`** (PAS blanc — texte foncé sur fond clair) |
| **L8** | Légende | Segoe UI | 10 pt | non | **`#474E67`** |
| **L9** | Titre de carte | Segoe UI | 12 pt | **oui** | **`#000000` noir** |
| **L9** | Texte corps court ("xxxxxx") | **Segoe UI** (Regular) | 10 pt | non | **`#000000` noir** (V2.3 : passé de Segoe UI Light à Segoe UI Regular) |
| **L9** | Texte sous séparateur (explicatif Parade/Levier) | Segoe UI Light | 10 pt | non | **`#000000` noir** |
| **L9** | Badges "Parade" / "Levier" | Segoe UI | 10 pt | non | **petites majuscules avec première lettre capitale** (`smallCaps` + texte saisi "Parade"/"Levier"), couleur `#8DAC95` |
| **L9** | Badge "Risque élevé" / "Risque moyen" / "Gain élevé" / "Gain moyen" | Segoe UI | 10 pt | non | **petites majuscules avec première lettre capitale** (`smallCaps` + texte saisi en casse normale), couleur dédiée |
| **L9** | Picto coin (Wingdings) | **Wingdings** | hérité | **oui** | couleur dédiée |
| **L10** | Numéro de phase ①②③ | (hérité Segoe UI) | 24 pt | **oui** | `#FFFFFF`, centré |
| **L10** | Titre de bande (Titre N) | (hérité) | 16 pt | **oui** | `#FFFFFF` |
| **L10** | Sous-titre de bande | (hérité) | 12 pt | non | `#FFFFFF` |
| **L10** | Titre de puce | Segoe UI | 11 pt | **oui** | **`#000000` noir** |
| **L10** | Corps de puce | Segoe UI Light | 10,5 pt | non | **`#474E67`** |
| **L11** | Numéro fantôme "01"/"02"/"03" | **Segoe UI Black** | 71,99 pt | **oui** | couleur pâle (`#BBB4C4`/`#D5B3BE`/`#FEE3CA`) **+ transparence 60 % (= alpha 40000 → 40 % d'opacité) pour effet filigrane** ⚠ injecter `<a:alpha val="40000"/>` dans le `<a:srgbClr>`, **placer en arrière-plan** (z-order : avant le titre du bloc) |
| **L11** | Titre du bloc | Segoe UI | hérité | **oui** | couleur de l'accent (`#6A5D79`/`#A25871`/`#FDA85B`) |
| **L11** | Corps du bloc | Segoe UI Light | 14 pt | non | **`#474E67`** |

> Les tailles sont mesurées via l'attribut `sz` des `<a:rPr>` (centièmes de pt → divisé par 100).

---

## 4. Structure récurrente de chaque slide

### 4.1 Zone titre (héritée du master)

```
Position : x=1,09 cm  y=0,71 cm
Taille   : 31,70 × 1,58 cm
Police   : Segoe UI Black 29,32 pt non bold, #484C6A
Align    : gauche
```

### 4.2 Petit trait décoratif (sous le titre) — DEUX éléments

⚠️ **Attention** : ce n'est PAS un seul rectangle. Le master comporte **un groupe de 2 éléments** dont les coordonnées absolues (après transformation du groupe) sont :

```
1) Rectangle plein épais
   Position : x=1,093 cm  y=2,461 cm
   Taille   : 1,867 × 0,267 cm
   Fill     : #484C6A (couleur titre)
   Line     : noLine

2) Connecteur ligne fine (qui dépasse à droite)
   Position : départ x=1,093 cm  y=2,707 cm  →  arrivée x=4,780 cm  y=2,707 cm  (longueur 3,687 cm)
   Couleur  : #112753 (accent2 du thème — bleu marine)
   Épaisseur: 1 pt (12700 EMU)
   Style    : ligne droite continue
```

> 🎯 **V2.2 — Reproductibilité au pixel près** : ces positions et dimensions ont été recalculées depuis le `<p:grpSp>` "Groupe 14" du `slideMaster1.xml` du template (transformation `chOff/chExt → off/ext` avec ratio 4/3). Toute valeur arrondie à 0,01 cm près est tolérée ; au-delà, l'écart est visible.

Visuellement : le rectangle épais en `#484C6A` est **suivi à sa droite par une ligne fine bleu marine** plus longue. Cette signature graphique est une marque distinctive du template.

### 4.3 Barre "Take away" (posée par le générateur sur les layouts qui l'utilisent)

```
Position : x=1,09 cm  y=16,65 cm  (V2.2 — remontée de 0,22 cm vs template d'origine)
Taille   : 31,70 × 1,10 cm
Fill     : gradient vertical 3 stops avec <a:shade> sur #A25871
           (shades 30% / 67,5% / 100%)
Texte    : "Take away" — Segoe UI 15,99 pt bold blanc, centré H+V
```

> 🎯 **V2.2 — Pourquoi cette remontée** : dans le master du template, le take away est à y=16,87 et le logo Safran à y=17,91 → chevauchement quasi pile (0,06 cm). Quand le logo est désormais explicitement posé sur chaque slide (cf. 4.4), il faut une marge réelle. Cible **y=16,65** → bottom de la barre = 17,75 cm → **marge 0,16 cm avant le top du logo**, c'est suffisant pour une séparation visible sans casser la composition.

> ⚠️ **L5 (Timeline), L9 (Risques) et L11 (Arc narratif) ont un comportement spécial** :
> - L5 : pas de Take away (zone vide)
> - L9 : pas de Take away (pas de zone du tout)
> - L11 : remplace Take away par un CTA personnalisé (texte différent, peut être plus long)

### 4.4 Pied de page (à poser sur CHAQUE slide par le générateur)

> ⚠️ **V2.2 — IMPORTANT** : si le pptx généré n'utilise pas le master du template (cas par défaut avec python-pptx qui ouvre une présentation neuve), **le logo Safran ne s'affiche pas automatiquement**. Le générateur doit donc **poser explicitement le logo sur chaque slide**.

> 🆕 **V2.3 — EXTENSION** : pour les mêmes raisons (master non hérité), **les 3 éléments suivants doivent aussi être posés explicitement sur chaque slide** : numéro de slide, séparateur vertical fin entre numéro et mention légale, mention légale complète. L'audit visuel a montré que ces éléments sont absents dans le pptx généré sans intervention.

```
Logo Safran      : (29,77 ; 17,91) cm, 3,03 × 0,64 cm — assets/logos/safran_logo.png
                   👉 À poser sur CHAQUE slide via slide.shapes.add_picture(...)
                   👉 Appeler kill_effects() sur l'image pour neutraliser l'ombre du thème
Numéro de slide  : (1,04 ; 18,53) cm — Segoe UI 6 pt #7D7B8D, numéro auto-incrémenté
                   👉 V2.3 — texte = str(slide_index) où slide_index commence à 1
                   👉 Largeur 0,40 cm hauteur 0,40 cm, aligné gauche, vertical_anchor MIDDLE
Séparateur vertical : (1,55 ; 18,55) cm — petit trait vertical 0,02 × 0,32 cm couleur #7D7B8D
                   👉 V2.3 — sépare le numéro de slide de la mention légale
                   👉 Connecteur ligne ou rectangle plein, épaisseur 0,5 pt
Mention légale   : (1,75 ; 18,51) cm — Segoe UI 6 pt #7D7B8D
                   👉 V2.3 — Texte exact (ne pas modifier) :
                   "This document and the information therein are the property of Safran. They must not be copied or communicated to a third party without the prior written authorization of Safran"
                   👉 Largeur 26,32 cm hauteur 0,40 cm, aligné gauche
Classification   : (15,65 ; 0,18) cm — "C2 - Confidential" orange (en haut)
                   👉 V2.3 — texte "C2 - Confidential" Segoe UI 10 pt couleur #FDA85B (orange thème), centré, à poser explicitement aussi
```

#### Code Python à inclure dans chaque slide générée

```python
from pptx.util import Cm, Pt
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.dml.color import RGBColor

LOGO_PATH = "assets/logos/safran_logo.png"
LOGO_X = Cm(29.77)
LOGO_Y = Cm(17.91)
LOGO_W = Cm(3.03)
LOGO_H = Cm(0.64)

LEGAL_TEXT = ("This document and the information therein are the property of Safran. "
              "They must not be copied or communicated to a third party without the "
              "prior written authorization of Safran")

def add_safran_logo(slide):
    """À appeler sur CHAQUE slide après création."""
    pic = slide.shapes.add_picture(LOGO_PATH, LOGO_X, LOGO_Y, width=LOGO_W, height=LOGO_H)
    kill_effects(pic)
    return pic

def add_footer(slide, slide_number):
    """V2.3 — Pose le footer complet : n° slide + séparateur vertical + mention légale.
    À appeler sur CHAQUE slide après création."""
    # 1) Numéro de slide
    num_box = slide.shapes.add_textbox(Cm(1.04), Cm(18.53), Cm(0.40), Cm(0.40))
    kill_effects(num_box)
    tf = num_box.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    r = p.add_run()
    r.text = str(slide_number)
    r.font.name = "Segoe UI"
    r.font.size = Pt(6)
    r.font.color.rgb = RGBColor(0x7D, 0x7B, 0x8D)

    # 2) Séparateur vertical fin (rectangle plein 0,02 × 0,32)
    sep = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Cm(1.55), Cm(18.55), Cm(0.02), Cm(0.32))
    sep.fill.solid()
    sep.fill.fore_color.rgb = RGBColor(0x7D, 0x7B, 0x8D)
    sep.line.fill.background()
    kill_effects(sep)

    # 3) Mention légale
    legal_box = slide.shapes.add_textbox(Cm(1.75), Cm(18.51), Cm(26.32), Cm(0.40))
    kill_effects(legal_box)
    tf = legal_box.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    r = p.add_run()
    r.text = LEGAL_TEXT
    r.font.name = "Segoe UI"
    r.font.size = Pt(6)
    r.font.color.rgb = RGBColor(0x7D, 0x7B, 0x8D)

def add_classification(slide):
    """V2.3 — Pose la mention 'C2 - Confidential' en haut. À appeler sur CHAQUE slide."""
    box = slide.shapes.add_textbox(Cm(15.65), Cm(0.18), Cm(2.64), Cm(0.42))
    kill_effects(box)
    tf = box.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r = p.add_run()
    r.text = "C2 - Confidential"
    r.font.name = "Segoe UI"
    r.font.size = Pt(10)
    r.font.color.rgb = RGBColor(0xFD, 0xA8, 0x5B)
```

> 🎯 **V2.3 — Règle d'or footer** : sur chaque slide, après le titre + trait + take away (ou équivalent), appeler **dans cet ordre** :
> 1. `add_classification(slide)` — pose le "C2 - Confidential" en haut
> 2. `add_safran_logo(slide)` — pose le logo en bas-droit
> 3. `add_footer(slide, slide_number)` — pose le n° de slide + séparateur + mention légale en bas-gauche
>
> **Aucune slide ne doit jamais quitter le générateur sans ces 3 appels.**

---

## 5. Inventaire des 11 layouts

| # | Nom | Description rapide | Take away ? |
|---|---|---|---|
| **L1** | **Hook factuel** | Manifesto gauche + 3 KPI à droite + 2 zones graphiques | ✅ |
| **L2** | **Hook 3 cartes** | 3 cartes verticales blanches roundRect avec barre couleur gauche + picto + titre + corps | ✅ |
| **L3** | **Liste 6 points** | 6 teardrops colorés en grille 3×2 + label "FACTEUR xxx" sous chaque | ✅ |
| **L4** | **Triptyque** | Triangle de 3 anneaux reliés (image bg) + 3 labels positionnés | ✅ |
| **L5** | **Timeline 4 phases** | 4 puces sur ligne horizontale + cercle numéroté + textes étape sous chaque | ❌ |
| **L6** | **Tableau 5 colonnes** | RoundRect blanc avec en-têtes colorés + 4 rangées alternance #F4F5F9/blanc | ✅ |
| **L7** | **Dashboard** | 6 KPI roundRect en haut + séparateur "Texte" + 5 barres de progression | ✅ |
| **L8** | **Comparatif** | Titre secondaire + légende 2 carrés + 5 rangées de barres bidirectionnelles rose/beige | ✅ |
| **L9** | **Risques & Opportunités** | **Fond #EFF1F6** + 6 cards 3×2 avec picto Wingdings + badge risque/gain + zones texte | ❌ |
| **L10** | **Plan d'action 3 phases** | 3 cards numérotées avec bande header colorée + 3 puces par card | ✅ |
| **L11** | **Arc narratif et CTA** | 3 blocs verticaux avec barre accent + numéro fantôme géant + titre + corps | CTA personnalisé |

> ⚠️ **Voir `references/layouts.md` pour les positions, dimensions et couleurs exactes de chaque layout.**

---

## 6. Assets disponibles dans `assets/`

### `assets/backgrounds/`
- `triangle_bg.png` — Image du triangle complet (3 anneaux + arcs décoratifs + barres) pour Layout 4
  - Position d'insertion : (9,50 ; 3,19) cm
  - Taille : 15,99 × 13,11 cm
  - Centres des 3 anneaux à utiliser pour positionner les labels :
    - Haut : `(16,74 ; 6,18)` cm
    - Bas-gauche : `(12,38 ; 13,38)` cm
    - Bas-droite : `(21,41 ; 13,36)` cm

### `assets/logos/`
- `safran_logo.png` — Logo principal PNG (hérité du master, bas-droit)
- `safran_logo_vector.svg` — Logo Safran vectoriel SVG
- `safran_logo_alt.svg` — Logotype Safran alternatif SVG
- `powered_by_trust.png` — Insigne "POWERED BY TRUST"

### `assets/pictos/` — 700×700 px, noir & blanc, fond transparent
- `picto_01_dialogue_circulaire.png`
- `picto_02_donnees_dossier.png`
- `picto_03_processus_valide.png`
- `picto_04_equipe_engrenage.png`
- `picto_05_dashboard_bi.png`
- `picto_06_chat_cascade.png`

> Ces pictos servent principalement pour **L2 (cartes en haut)** et **L4 (centrés sur les anneaux du triangle)**. Ils peuvent aussi être utilisés en libre dans L1 si besoin.

---

## 7. Workflow de génération (à suivre dans l'ordre)

1. **Identifier** le(s) layout(s) nécessaire(s) parmi les 11 documentés (voir section 5)
2. **Lire** `references/layouts.md` pour les spécifications exactes du ou des layouts choisis
3. **Lire** le skill `pptx` (`/mnt/skills/public/pptx/SKILL.md`) pour la mécanique python-pptx
4. **Construire** chaque slide selon les spécifications du layout :
   - **L4** : insérer `assets/backgrounds/triangle_bg.png` aux coordonnées documentées, puis superposer pictos et labels
   - **L1, L2, L3, L5–L11** : reconstruire depuis les mesures OOXML (rectangles + ellipses + lignes + texte)
   - **L1** : utiliser des **placeholders d'image** pour les 2 zones graphiques (l'utilisateur fournira ses propres graphes)
5. **Appliquer** systématiquement sur les slides concernées : titre, petit trait décoratif, barre Take away, logo, pied de page
6. **Pour L9** : NE PAS poser la barre Take away ; **mettre le fond du slide à `#EFF1F6`**
7. **Pour L5** : NE PAS poser la barre Take away
8. **Pour L11** : remplacer la barre Take away par un CTA personnalisé (rectangle gradient identique mais texte différent, plus long)
9. **Vérifier** via la checklist de conformité ci-dessous avant de livrer

---

## 7.bis Workflow d'implémentation par layout (OBLIGATOIRE — anti-improvisation)

> ⚠️ **Cette section est non-négociable.** Toute improvisation sur un point de layout est INTERDITE. Si un point n'est pas clair → poser la question avant de coder.

### Étape 1 — Identifier les layouts requis
- Lire la commande utilisateur et noter chaque layout utilisé (ex : L1, L9)
- Ouvrir `references/layouts.md` et localiser **chaque layout** concerné

### Étape 2 — Créer une checklist par layout (copiée depuis `layouts.md`)
Pour chaque layout, extraire et noter :
- Positions exactes (x, y en cm) de chaque élément
- Dimensions exactes (largeur, hauteur en cm)
- Couleurs exactes (codes HEX)
- Polices, tailles, styles
- Comportements spéciaux (fond de slide différent, barre Take away absente, picto Wingdings, etc.)

### Étape 3 — Ne coder QUE si tous les points sont compris
- Si un point de la checklist est ambigu ou non spécifié dans `layouts.md` → **DEMANDER** à l'utilisateur
- Phrase clé : *« Ce point n'est pas dans ma checklist ou je ne suis pas sûr — je demande avant de coder plutôt que d'improviser. »*
- **Signal d'alerte** : si je me surprends à dire *« pour la lisibilité je vais… »* ou *« j'improvise… »* → c'est un point non clair, poser la question.

### Étape 4 — Coder en cochant la checklist
- Implémenter élément par élément en se référant à la checklist
- Cocher chaque point au fur et à mesure
- Ne jamais « adapter » une spec par intuition ou esthétique

### Étape 5 — Valider la checklist avant QA
- Relire la checklist complète
- Vérifier que 0 point n'est laissé de côté
- Puis passer à la checklist de conformité section 8

### Points de vigilance spécifiques par layout

#### L1 — Hook factuel
- ✅ **Barre accent gauche** verticale `#A25871` (0,11 × 6,9 cm) à (1,69 ; 3,37) cm
- ✅ **Manifesto** : Segoe UI Light 24 pt couleur **`#474E67`**, **mots clés en bold NOIR `#000000`** (V2.3 — plus de couleurs palette type `#6A5D79`/`#A25871`), **interligne multiple 1,5** (`paragraph.line_spacing = 1.5`)
- ✅ **Sous-narration** : Segoe UI 13 pt couleur **`#474E67`**, **mots clés en bold NOIR `#000000`** (V2.3), **interligne multiple 1,35** (`paragraph.line_spacing = 1.35`)
- ✅ **3 KPI** alignés à droite à x=24,20 cm, chacun = `KpiAccent` (1,13×0,07 cm) + `KpiVal` (44 pt Segoe UI Black couleur palette KPI) + `KpiLbl` (13 pt bold **`#000000` noir**) + `KpiSub` (10 pt **`#474E67`** — V2.3 : repassé en `#474E67`, plus en NOIR)
- ✅ **2 zones d'image** placeholders pour graphes utilisateur : (1,34 ; 11,67) 11,09×4,57 cm et (12,14 ; 11,67) 11,35×4,57 cm
- ❌ Interdit : remplir les zones d'image avec du contenu fictif

#### L2 — Hook 3 cartes
- ✅ **Card = roundRect blanc** (9,64 × 8,11 cm) — fond blanc, **AUCUNE bordure** (`shape.line.fill.background()`)
- ✅ **Barre verticale colorée** à gauche de chaque card (0,10 × 9,90 cm), couleurs `#6A5D79` / `#A25871` / `#FDA85B`
- ✅ **Picto** 2,0 × 2,0 cm en haut de chaque card
- ✅ **Titre** Segoe UI Corps 20 pt bold, **petites majuscules avec première lettre capitale** (texte saisi en casse normale, ex. "Le plan d'action doit vivre sur le terrain", + `run.font._rPr.set('cap', 'small')` ou via `XML <a:rPr cap="small">`), couleur de la barre
- ✅ **Corps** Segoe UI Light 14 pt couleur **`#474E67`**, **interligne multiple 1,3** (`paragraph.line_spacing = 1.3`)
- ❌ Interdit : appliquer une bordure colorée sur la card entière (la barre verticale est SEULE)
- ❌ Interdit : laisser une ombre sur les cards ou la barre (utiliser `kill_effects()`)
- ❌ Interdit : saisir le titre en MAJUSCULES dans le texte (utiliser `cap="small"` sur du texte mixte normal)

#### L3 — Liste 6 teardrops
- ✅ 6 teardrops natifs OOXML en grille 3×2 aux 6 positions documentées dans `layouts.md`, couleurs palette claire
- ✅ **Label sous chaque teardrop** : run mixte avec :
  - **Premier mot "Facteur"** : Segoe UI **14 pt bold**, **petites majuscules avec première lettre capitale** (texte saisi "Facteur" + `cap="small"` injecté dans `<a:rPr>`), couleur `#000000`
  - **Suite "xxxxx"** : Segoe UI 14 pt non bold, `#000000`, casse normale
- ✅ Texte du label centré horizontalement
- ❌ Interdit : saisir "FACTEUR" en MAJUSCULES dures dans le texte (utiliser `cap="small"` sur du texte normalement capitalisé)

#### L4 — Triptyque
- ✅ Labels texte positionnés selon les coordonnées exactes de `layouts.md` (au-dessus, à gauche, à droite des anneaux)
- ✅ Insérer l'asset rastérisé `triangle_bg.png` (15,99 × 13,11 cm à (9,50 ; 3,19) cm)
- ✅ **1ère ligne (titre)** : Segoe UI **18 pt bold** couleur `#000000` noir
- ✅ **2e ligne (sous-titre)** : Segoe UI **14 pt** non bold couleur `#474E67`
- ❌ Interdit : tenter de redessiner les arcs décoratifs en custGeom

#### L5 — Timeline
- ✅ **Ligne horizontale fine** (0,05 cm) entre les puces, couleur palette claire pour chaque segment
- ✅ **🎯 V2.3 — Ligne horizontale APRÈS la 4ème puce aussi** : par cohérence visuelle avec les 3 autres puces, ajouter un rectangle ligne de **couleur claire `#FEE3CA`** (couleur claire de la phase 4 = orange/beige pâle) à (X4+0,42 ; 6,91) cm de taille **6,83 × 0,05 cm**, où X4 = 24,92 cm. La ligne dépasse à droite mais c'est l'effet voulu (elle se prolonge jusqu'au bord visuel de la slide).
- ✅ **Petit cercle plein** au début (0,42 × 0,42 cm) puis **gros cercle numéroté** (0,92 × 0,92 cm)
- ✅ **Position Y de la ligne** : 6,91 cm ; **Y des cercles** : 6,72 cm (petit) et 7,64 cm (gros)
- ✅ **🎯 V2.2 — UNIFORMITÉ DES 4 PUCES** : la mise en forme des zones de texte sous chaque puce doit être **strictement identique pour les 4 puces** (1, 2, 3 ET 4). Pas de logique conditionnelle qui traiterait la 4ème différemment. Récap de la mise en forme à reproduire à l'identique sous chaque puce :
  - **Période ("T1 — AVR › JUIN" / "T2 — JUIL › SEPT" / "T3 — OCT › DÉC" / "2027 — S1")** : Segoe UI **12 pt bold**, couleur de la phase (`#484C6A` / `#6A5D79` / `#D4737A` / `#FDA85B`)
  - **Titre étape ("Cadrage" / "Conception" / "Déploiement" / "Consolidation")** : Segoe UI **15 pt bold**, **`#000000` NOIR** — y compris pour la 4ème puce (PAS 16 pt et PAS `#474E67`)
  - **Description étape** : Segoe UI Light **12 pt**, **`#474E67`**, **interligne 1,3** — y compris pour la 4ème puce (PAS 15 pt et PAS noir)
- ✅ Pas de barre Take away

#### L6 — Tableau
- ✅ **Conteneur roundRect blanc** (1,08 ; 4,94) 31,70 × 6,95 cm — sert de "fond" du tableau
- ✅ **En-tête entier en `#6A5D79`** avec texte 16 pt bold blanc (différent de l'ancien template qui avait des couleurs par colonne)
- ✅ Alternance rangées : blanc / `#F4F5F9` / blanc / `#F4F5F9`
- ✅ Séparateurs horizontaux fins `#D8DBE8` (0,02 cm)
- ✅ **1ère colonne : titre 14 pt bold `#000000` NOIR** (PAS `#474E67`)
- ✅ Cellules autres colonnes : 14 pt **`#474E67`**
- ✅ Colonne "écart" : valeur 14 pt bold `#6A5D79`

#### L7 — Dashboard
- ✅ **🎯 V2.3 — CENTRAGE HORIZONTAL DU BLOC ENTIER** : le bloc visuel (6 KPI + séparateur + 5 jauges) doit être **symétrique horizontalement dans la slide** (largeur slide 33,87 cm).
  - **Bloc 6 KPI** : largeur totale = 27,18 (x KPI6) + 5,00 (largeur KPI6) − 1,06 (x KPI1) = **31,12 cm** → marge gauche = (33,87 − 31,12) / 2 = **1,375 cm**. Donc **décaler tous les x KPI de +0,315 cm** par rapport aux valeurs V2.2 (KPI1 → 1,375 cm au lieu de 1,06).
  - **Séparateur** : déjà à (1,09 ; 8,50) avec largeur 31,08 cm → marge gauche = (33,87 − 31,08) / 2 = 1,395 cm → ajuster **x séparateur à 1,395 cm** au lieu de 1,09.
  - **Bloc 5 jauges** : track jauge largeur fixe 23,89 cm à x=8,29 cm + label gauche à x=1,06 largeur 6,94 cm. Largeur totale jauge+label = (8,29 + 23,89) − 1,06 = 31,12 cm → décaler de +0,315 cm aussi (label à x=1,375 ; track à x=8,605 cm).
  - **NB** : ces 3 décalages doivent être **identiques en valeur absolue** pour préserver l'alignement vertical entre les 3 zones (sinon les KPI ne sont plus alignés avec les jauges en dessous).
- ✅ 6 KPI roundRect (y=3,70 cm, h=4,44 cm), fonds palette claire (lavande / violet pâle / rose poudré / rose pâle / beige / jaune pâle)
- ✅ **🎯 V2.2 — Texte chiffre KPI Segoe UI 36 pt bold : couleur PALETTE FONCÉE associée au fond** (et non plus uniformément `#474E67`) — centré. Mapping fond → couleur chiffre :

| KPI | Fond (couleur claire) | Texte chiffre 36 pt (couleur foncée) |
|---|---|---|
| KPI1 | `#BABDD0` (lavande clair) | **`#484C6A`** (bleu gris foncé) |
| KPI2 | `#BBB4C4` (violet pâle) | **`#6A5D79`** (violet grisé) |
| KPI3 | `#D5B3BE` (rose poudré) | **`#A25871`** (vieux rose foncé) |
| KPI4 | `#F1D3D5` (rose pâle) | **`#D4737A`** (rose corail) |
| KPI5 | `#FEE3CA` (beige pêche) | **`#FDA85B`** (orange doux) |
| KPI6 | `#FEF4DA` (jaune très pâle) | **`#FBCC58`** (jaune moutarde) |

- ✅ **Sous-label KPI Segoe UI 11 pt couleur `#474E67`** — centré (inchangé V2.1)
- ✅ **Séparateur "Texte" / "Performance par segment"** : rectangle `#F4F5F9` à (1,395 ; 8,50) 31,08 × 1,17 cm (V2.3 : x recentré), **texte Segoe UI 12 pt bold italique couleur `#000000` NOIR**
- ✅ 5 barres de progression aux y=10,28 / 11,53 / 12,78 / 14,04 / 15,29 cm (track) et labels respectifs aux y=10,09 / 11,40 / 12,68 / 13,96 / 15,18 cm
- ✅ **🎯 V2.3 — Labels gauche des jauges Segoe UI 11 pt BOLD couleur `#000000` NOIR** (V2.3 : passé en BOLD ; auparavant non bold), **avec alignement vertical centré sur la barre** :
  - La barre (track) a une hauteur de 0,78 cm. Pour centrer le label verticalement avec la barre, il faut que le **centre Y du label = centre Y de la barre**.
  - **Méthode** : poser la zone texte du label à la même Y que la barre (10,28 / 11,53 / ...) avec hauteur 0,78 cm (égale à celle de la barre) au lieu de 0,97 cm comme précédemment, ET utiliser `text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE` pour centrer le texte verticalement dans la zone.
  - Résumé : **label à y=y_track (pas y_label−0,19), hauteur 0,78 cm égale à la barre, vertical_anchor = MIDDLE**.
- ✅ **🎯 Jauges (track + fill) aux extrémités arrondies en CAPSULE** : utiliser `MSO_SHAPE.ROUNDED_RECTANGLE` puis **forcer le rayon d'angle au maximum** pour obtenir un effet "pilule" (extrémités semi-circulaires).
  - Le rayon d'angle d'un `roundRect` python-pptx = `shape.adjustments[0]` (valeur entre 0 et 0,5, fraction de la plus petite dimension).
  - Pour des extrémités parfaitement arrondies (capsule) : `shape.adjustments[0] = 0.5` (rayon = h/2 = 0,39 cm pour barre de 0,78 cm de hauteur).
  - Code Python à appliquer **sur les 5 tracks ET les 5 fills** :
    ```python
    bar = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    bar.adjustments[0] = 0.5  # capsule : rayon = h/2
    kill_effects(bar)
    ```
- ❌ Interdit : laisser le rayon par défaut (≈ 0,1) qui donne des coins légèrement arrondis mais pas un effet capsule
- ❌ Interdit (V2.2) : mettre uniformément `#474E67` sur tous les chiffres KPI — chaque KPI doit avoir sa couleur foncée dédiée selon le mapping ci-dessus.
- ❌ Interdit (V2.3) : laisser les labels gauche jauges en non bold OU en gris OU avec un alignement vertical haut (top) au lieu de centré.

#### L8 — Comparatif
- ✅ Titre secondaire 21,3 pt bold `#685D79` à (1,08 ; 4,04)
- ✅ Légende avec 2 carrés couleurs et **labels en couleur `#474E67`** (pas en gris)
- ✅ 5 rangées de barres bidirectionnelles
- ✅ **Labels gauche des 5 rangées Segoe UI 12 pt bold couleur `#000000` NOIR, ALIGNÉS À GAUCHE** (`PP_ALIGN.LEFT` — pas `RIGHT`, et plus en `#474E67`)
- ✅ **Valeurs numériques dans les barres Segoe UI 12 pt bold couleur `#474E67`** (PAS blanc — texte foncé sur fond clair rose/beige pour lisibilité)
- ✅ **🎯 V2.2 — Extrémités arrondies des barres** : `shape.adjustments[0] = 0.3` sur **les 10 barres** (5 roses + 5 beiges). Cela reproduit le `<a:gd fmla="val 30000"/>` du template (= 30 % du petit côté). C'est un arrondi modéré (≠ capsule du L7 qui est à 0.5). Sans cette ligne, les barres ont des coins quasi droits, ce qui n'est pas conforme.
  ```python
  bar = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
  bar.adjustments[0] = 0.3  # arrondi modéré 30 %, ≠ capsule (0.5)
  kill_effects(bar)
  ```

#### L9 — Risques & Opportunités
- ✅ **Fond du slide entier = `#EFF1F6`** (pas blanc !)
- ✅ Pas de barre Take away
- ✅ 6 cards 3×2 = 10,90 × 6,41 cm chacune, roundRect blanc avec **fine bordure `tx2` modulée** (0,01 cm)
- ✅ **Picto Wingdings** dans roundRect 0,90 × 1,00 cm en haut-gauche : caractère `J` (Wingdings = ☺) ou `L` (Wingdings = ☹) — gardé tel quel comme l'original
- ✅ **Titre de card** : Segoe UI **12 pt bold couleur `#000000` NOIR** (PAS `#474E67`)
- ✅ **🎯 V2.3 — Texte corps court "xxxxxx"** : **Segoe UI Regular 10 pt** couleur `#000000` NOIR (V2.3 : passé de Segoe UI Light à Segoe UI Regular pour densité visuelle plus marquée — texte plus présent)
- ✅ **Texte explicatif (sous le badge Parade/Levier)** : Segoe UI Light 10 pt couleur **`#000000` NOIR** (reste en Light — c'est uniquement le texte court "xxxxxx" du haut de card qui passe en Regular)
- ✅ **🎯 V2.3 — Badge risque/gain en MODE CAPSULE** : roundRect 2,49 × 0,53 cm avec **`adjustments[0] = 0.5`** (capsule, rayon = h/2 = 0,265 cm). Couleurs dédiées (#FF9797/#FEE3CA/#69FFAD/#FFFF85). **Texte du badge en petites majuscules avec première lettre capitale** (ex. saisi "Risque élevé", "Risque moyen", "Gain élevé", "Gain moyen" — `cap="small"` sur le run)
- ✅ **🎯 V2.3 — Ligne pointillée séparatrice** au milieu de la card : utiliser **`dash="sysDot"`** (pointillés serrés) au lieu de `dash="dash"` (tirets longs). Couleur tx2 lumMod=20000 lumOff=80000 (gris très clair) inchangée.
- ✅ **🎯 V2.3 — Petit badge "Parade" / "Levier" EN MODE CAPSULE** : roundRect 1,71 × 0,53 cm avec **`adjustments[0] = 0.5`**. Fill `#DDE7CF` (vert pâle uniforme). **Texte en petites majuscules avec première lettre capitale** (saisi "Parade" / "Levier" + `cap="small"`), couleur `#8DAC95`
- ❌ Interdit : saisir les badges en MAJUSCULES dures ("RISQUE ÉLEVÉ", "PARADE") — utiliser `cap="small"` sur du texte capitalisé normalement
- ❌ Interdit (V2.3) : laisser les badges avec un arrondi par défaut (≈0,1) au lieu de la capsule (0,5).
- ❌ Interdit (V2.3) : laisser le texte court "xxxxxx" en Segoe UI Light — il doit être en Segoe UI Regular.
- ❌ Interdit (V2.3) : laisser la ligne pointillée en `dash="dash"` (tirets longs) — il faut `dash="sysDot"` (pointillés serrés).

#### L10 — Plan d'action 3 phases
- ✅ **Card = rectangle plein blanc** (10,50 × 11,49 cm) avec **bordure `ln w=19050` (1,5 pt)** de la couleur de phase
- ✅ **Bande header** rectangle plein 10,50 × 2,10 cm de la couleur de phase, en haut de la card
- ✅ **Numéro Unicode ①②③** (24 pt bold blanc `#FFFFFF`) à (X+0,17 ; Y+0,20) cm — police par défaut du thème (Segoe UI)
- ✅ **🎯 V2.3 — 3 puces avec ALIGNEMENT VERTICAL CENTRÉ entre bullet et titre** : pour chaque puce, le **centre Y du cercle plein doit être identique au centre Y de la zone titre**. Implémentation :
  - Le cercle plein a une hauteur de 0,44 cm. Centré sur Y_centre, il va de Y_centre−0,22 à Y_centre+0,22.
  - La zone titre a actuellement une hauteur de 1,02 cm. Pour avoir son centre Y aligné avec celui du cercle, **réduire la hauteur de la zone titre à 0,44 cm** (égale au cercle) ET utiliser `text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE` pour centrer le texte verticalement dans la zone.
  - **Y_titre dans cette nouvelle convention = Y_cercle (les deux à la même Y de top)** car les deux ont la même hauteur 0,44 cm.
  - Le corps de puce reste à Y_corps inchangé (sous le cercle+titre).
  - **Y_cercle = Y_titre par puce** :
    - Puce 1 : Y_cercle = Y_titre = **6,59 cm** (anciennement Y_titre=6,30 + h=1,02 ; on adopte la même Y que le cercle)
    - Puce 2 : Y_cercle = Y_titre = **9,36 cm**
    - Puce 3 : Y_cercle = Y_titre = **12,51 cm**
- ✅ **3 puces** : petit cercle plein 0,44 cm couleur de phase + **titre Segoe UI bold 11 pt couleur `#000000` NOIR** (PAS `#474E67`) + **corps Segoe UI Light 10,5 pt couleur `#474E67`**
- ✅ Ligne séparatrice 0,5 pt `#E0E0E8` entre les puces

#### L11 — Arc narratif et CTA
- ✅ **3 blocs verticaux** : barre accent gauche `#6A5D79` / `#A25871` / `#FDA85B` (0,18 × 3,80 cm)
- ✅ **Numéro fantôme géant** "01" / "02" / "03" en **Segoe UI Black 71,99 pt** :
  - Couleur palette claire **`#BBB4C4`** (phase 1) / **`#D5B3BE`** (phase 2) / **`#FEE3CA`** (phase 3)
  - **+ Transparence 60 % pour effet filigrane** = **`<a:alpha val="40000"/>`** (alpha 40000 millièmes = 40 % d'opacité = 60 % de transparence — c'est strictement la même valeur, juste deux façons de la nommer)
  - Position : x=1,80 cm
  - **🎯 Z-ORDER OBLIGATOIRE : numéro fantôme en ARRIÈRE-PLAN, posé en PREMIER, avant la barre accent et avant le titre du bloc.** Sans cela, le filigrane recouvre le titre au lieu d'être derrière.
  - **🚨 V2.2 — CAUSE RACINE FIX** : dans la version V2.1, le code utilisait `etree.SubElement(rPr, qn('a:solidFill'))` qui **ajoute en fin de rPr, après `<a:latin>`**. Or l'ordre XML imposé par le schéma OOXML est `solidFill` AVANT `latin`. Quand l'ordre est violé, **PowerPoint ignore le `solidFill`** et le numéro apparaît en couleur par défaut (noir). Il faut donc **insérer en première position** du rPr.
  - **Code Python d'injection alpha CORRIGÉ V2.2** (à appliquer sur le run du numéro) :
    ```python
    from lxml import etree
    from pptx.oxml.ns import qn

    rPr = run._r.get_or_add_rPr()
    # 1) Nettoyer tout solidFill existant
    for sf in rPr.findall(qn('a:solidFill')):
        rPr.remove(sf)
    # 2) Construire le nouveau solidFill avec alpha
    sf = etree.Element(qn('a:solidFill'))
    srgb = etree.SubElement(sf, qn('a:srgbClr'))
    srgb.set('val', 'BBB4C4')  # ou D5B3BE / FEE3CA selon phase
    alpha = etree.SubElement(srgb, qn('a:alpha'))
    alpha.set('val', '40000')  # 40 % d'opacité = 60 % de transparence
    # 3) ⚠️ INSÉRER EN POSITION 0 (avant <a:latin>) — sinon PowerPoint ignore le fill !
    rPr.insert(0, sf)
    ```
  - **Mise en arrière-plan** (à appliquer après création du textbox du numéro) : déplacer l'élément XML du numéro tout au début de la liste des shapes du `spTree` :
    ```python
    spTree = num_textbox._element.getparent()
    spTree.remove(num_textbox._element)
    spTree.insert(2, num_textbox._element)  # après nvGrpSpPr+grpSpPr (positions 0 et 1)
    ```
  - **Vérification de conformité** : ouvrir le `.pptx` généré, dépacker le `slide11.xml`, et vérifier que le run du "01" contient bien :
    ```xml
    <a:rPr sz="7199" b="1">
      <a:solidFill>
        <a:srgbClr val="BBB4C4">
          <a:alpha val="40000"/>
        </a:srgbClr>
      </a:solidFill>
      <a:latin typeface="Segoe UI Black"/>
    </a:rPr>
    ```
    avec **`solidFill` AVANT `latin`**. Si l'ordre est inversé → bug V2.1 non corrigé.
- ✅ **Titre du bloc** par-dessus le numéro (à x=2,00 cm), bold, couleur de l'accent foncée (`#6A5D79`/`#A25871`/`#FDA85B`)
- ✅ **Corps Segoe UI Light 14 pt couleur `#474E67`**
- ✅ **CTA en bas** = même rectangle que Take away mais avec texte personnalisé long (peut tenir sur 2 lignes si nécessaire)

---

## 8. Checklist de conformité (vérification finale OBLIGATOIRE)

### Éléments communs à toutes les slides
- [ ] Dimensions slide : 33,87 × 19,05 cm
- [ ] Fond blanc pur `#FFFFFF` (sauf L9 = `#EFF1F6`)
- [ ] **Aucune ombre sur aucune forme** : `kill_effects()` appelé sur **toutes** les shapes (rect, roundRect, ovale, ligne, image, textbox)
- [ ] Titre positionné à (1,09 ; 0,71) cm, 31,70×1,58 cm, **Segoe UI Black** 29,32 pt non bold, couleur `#484C6A`
- [ ] **🎯 V2.2 — Trait sous titre = 2 éléments aux POSITIONS PIXEL-PERFECT** : rect plein `#484C6A` à **(1,093 ; 2,461) cm de taille 1,867 × 0,267** (et NON 1,33 ; 2,72 ; 1,40 × 0,20) **+ ligne fine `#112753` 1 pt de longueur 3,687 cm démarrant à (1,093 ; 2,707)** (et NON 2,77 cm depuis 1,33 ; 2,91)
- [ ] **🎯 V2.2 — Barre "Take away" à (1,09 ; 16,65) cm** (au lieu de 16,87 — remontée de 0,22 cm pour libérer la zone du logo Safran ; marge 0,16 cm avant le top du logo), 31,70×1,10 cm, gradient 3 stops avec `<a:shade>` 30/67,5/100 sur `#A25871` — **SAUF L5, L9, L11**
- [ ] Texte "Take away" 15,99 pt bold blanc centré H+V (texte personnalisé pour L11)
- [ ] **🎯 V2.2 — Logo Safran posé EXPLICITEMENT sur CHAQUE slide** par le générateur Python à (29,77 ; 17,91) cm, taille 3,03 × 0,64 cm — fichier `assets/logos/safran_logo.png`, avec `kill_effects()` appliqué
- [ ] **🆕 V2.3 — `add_footer(slide, n)` appelé sur CHAQUE slide** : pose le **numéro de slide** (1,04 ; 18,53) Segoe UI 6 pt `#7D7B8D` + **séparateur vertical fin** (1,55 ; 18,55) 0,02×0,32 cm `#7D7B8D` + **mention légale complète** (1,75 ; 18,51) Segoe UI 6 pt `#7D7B8D` "This document and the information therein..."
- [ ] **🆕 V2.3 — `add_classification(slide)` appelé sur CHAQUE slide** : pose la mention "C2 - Confidential" à (15,65 ; 0,18) Segoe UI 10 pt `#FDA85B` (orange thème), centré
- [ ] **Tous les textes corps en `#474E67`** par défaut, **avec exceptions documentées en NOIR `#000000`** : titre étape L5, 1ère colonne L6, labels gauche L8, titres+corps cards L9, titres puces L10, séparateur+labels jauges L7, labels L4 1re ligne, "Facteur" L3, **mots clés en emphase L1 manifesto (V2.3)**, **labels KPI L1 13 pt** ; couleurs palette pour titres/accents ; blanc sur fonds colorés foncés (en-têtes L6, bandes header L10) — **NB V2.3 : sous-labels KPI L1 (10 pt) repassés en `#474E67`**

### Spécifique aux layouts
- [ ] **L1** : barre accent `#A25871` (1,69 ; 3,37) ; manifesto Segoe UI Light 24 pt **interligne 1,5** avec **🎯 V2.3 mots clés en bold NOIR `#000000`** (plus en couleurs palette) ; sous-narration 13 pt **interligne 1,35** avec mots clés en bold NOIR ; 3 KPI à x=24,20 cm avec accent + chiffre 44 pt Black + label 13 pt **NOIR** + sublabel 10 pt **`#474E67`** (V2.3 — repassé en `#474E67`) ; 2 zones d'image placeholder
- [ ] **L2** : 3 cards roundRect blanches 9,64×8,11 cm aux x=2,11 / 12,11 / 22,53 cm ; barre verticale gauche colorée 0,10×9,90 cm ; titres 20 pt **petites majuscules avec 1ère lettre cap (`cap="small"`, PAS texte saisi en MAJUSCULES)** couleur barre ; corps Segoe UI Light 14 pt **interligne 1,3**
- [ ] **L3** : 6 teardrops natifs OOXML aux 6 positions documentées ; labels en run mixte = "Facteur" 14 pt bold **petites majuscules avec 1ère lettre cap (`cap="small"`)** + " xxxxx" 14 pt non bold, **`#000000`**
- [ ] **L4** : image `triangle_bg.png` à (9,50 ; 3,19) cm taille 15,99×13,11 cm + 3 labels positionnés selon coordonnées, **titre 18 pt bold noir + sous-titre 14 pt `#474E67`**
- [ ] **L5** : 4 puces timeline horizontale (Y ligne=6,91 ; Y petit cercle=6,72 ; Y gros cercle=7,64) ; **🎯 V2.2 — les 4 puces ont la MÊME mise en forme** : période 12 pt bold couleur de phase, titre étape 15 pt bold `#000000`, description Segoe UI Light 12 pt `#474E67` interligne 1,3 ; **🎯 V2.3 — ajouter une LIGNE HORIZONTALE `#FEE3CA` après la 4ème puce** à (X4+0,42 ; 6,91) 6,83×0,05 cm ; **PAS de Take away**
- [ ] **L6** : roundRect blanc conteneur (1,08 ; 4,94) 31,70×6,95 cm ; en-tête entier `#6A5D79` ; 4 rangées alternance ; **1ère colonne `#000000` NOIR**
- [ ] **L7** : 6 KPI roundRect (y=3,70 cm) + séparateur "Texte" + 5 barres de progression (y=10,28 à 15,29 cm) ; **🎯 V2.3 — BLOC ENTIER CENTRÉ HORIZONTALEMENT** : décaler les x KPI/séparateur/jauges de **+0,315 cm** vs V2.2 (KPI1 à 1,375 / sep à 1,395 / label jauge à 1,375 / track jauge à 8,605) ; **jauges en CAPSULE (`adjustments[0]=0.5`)** ; **🎯 V2.2 — chiffres KPI 36 pt en COULEUR PALETTE FONCÉE** : KPI1=`#484C6A`, KPI2=`#6A5D79`, KPI3=`#A25871`, KPI4=`#D4737A`, KPI5=`#FDA85B`, KPI6=`#FBCC58` ; **🎯 V2.3 — Labels gauche 5 jauges en BOLD NOIR + centrés verticalement sur la barre** (zone texte h=0,78 cm égale à barre + `vertical_anchor=MIDDLE`)
- [ ] **L8** : titre secondaire 21,3 pt `#685D79` + 5 rangées de barres bidirectionnelles rose/beige ; **labels gauche en `#000000` NOIR aligné gauche** ; **valeurs dans barres en `#474E67` (PAS blanc)** ; **🎯 V2.2 — les 10 barres roundRect avec `adjustments[0]=0.3`** (arrondi modéré 30 %, ≠ capsule du L7)
- [ ] **L9** : **fond `#EFF1F6`** ; 6 cards 3×2 (10,90×6,41 cm) ; picto Wingdings J/L ; **titres cards 12 pt bold `#000000` NOIR** ; **🎯 V2.3 — corps "xxxxxx" Segoe UI REGULAR 10 pt `#000000` NOIR** (PAS Light) ; **🎯 V2.3 — badges Risque/Gain ET Parade/Levier en MODE CAPSULE (`adjustments[0]=0.5`)** ; **🎯 V2.3 — ligne pointillée séparatrice avec `dash="sysDot"` (pointillés serrés)** au lieu de `dash="dash"` ; **badges Parade/Levier/Risque/Gain en petites majuscules avec 1ère lettre cap (`cap="small"`)** ; **PAS de Take away**
- [ ] **L10** : 3 cards (0,61 / 11,68 / 22,86 cm × y=4,10 cm) 10,50×11,49 cm avec bordure 1,5 pt + bande header 10,50×2,10 cm + numéro ①②③ + 3 puces ; **titres puces Segoe UI bold 11 pt `#000000` NOIR** ; **🎯 V2.3 — bullet (cercle 0,44 cm) ET zone titre alignés au milieu verticalement** : zone titre h=0,44 cm (= cercle) avec `vertical_anchor=MIDDLE`, Y_titre = Y_cercle (6,59 / 9,36 / 12,51 cm)
- [ ] **L11** : 3 blocs avec barre accent + numéro fantôme 71,99 pt **alpha 40000 (= 60 % de transparence) + ARRIÈRE-PLAN (z-order tout au fond)** + titre bold + corps ; CTA en bas remplaçant Take away ; **🎯 V2.2 — VÉRIFIER que `<a:solidFill>` est inséré EN POSITION 0 du `<a:rPr>` (avant `<a:latin>`)** sinon le numéro apparaîtra en NOIR au lieu de la couleur palette filigrane

---

## 9. Points de vigilance critiques

> ⚠️ Voir aussi **section 7.bis** pour les vigilances spécifiques par layout à consulter AVANT de commencer à coder.

1. **Titre : Segoe UI Black 29,32 pt `#484C6A`** — définis explicitement dans le `titleStyle` du master. La graisse vient de la police Black elle-même (`bold=false` dans le run). Ne pas se fier à la couleur `dk2` du thème (`#474E67`).
2. **L9 a un fond gris bleuté `#EFF1F6`, pas blanc** — c'est unique parmi les 11 layouts.
3. **L9 utilise des caractères Wingdings** : `J` = ☺ (smiley) et `L` = ☹ (frowny). Garder la police Wingdings dans le run pour respecter l'original. Risque de fallback hors Windows/Office, mais c'est conforme à l'original.
4. **Le gradient Take away utilise `<a:shade>`** — pas 3 stops de même couleur ; c'est un gradient vertical avec modulation via shade, encodé directement en XML.
5. **Le petit trait décoratif sous le titre** est facilement oublié — issu du groupe "Groupe 14" du master, positions absolues V2.2 : rect épais (1,093 ; 2,461) 1,867×0,267 + ligne fine départ (1,093 ; 2,707) longueur 3,687.
6. **L2 = barre verticale gauche colorée + card roundRect blanche** ; pas de bordure complète colorée. NE PAS confondre avec un layout type "card bordée".
7. **L4 — anneaux et arcs décoratifs** : ce sont des formes libres (`custGeom`) non reproductibles simplement en python-pptx. Utiliser l'image rastérisée `assets/backgrounds/triangle_bg.png`.
8. **L4 — Labels positionnés selon les coordonnées exactes** de `layouts.md` — jamais dans des cartes, jamais dans les cercles, jamais à des positions approximatives.
9. **L5 et L11 n'ont pas de Take away classique**. L9 non plus.
10. **L11 — numéros fantômes** : ce sont des chiffres en arrière-plan, énormes (72 pt), couleur pâle de la palette **avec alpha 40000 (60 % de transparence)**. Le numéro est **placé en arrière-plan dans le z-order** : posé en premier, le titre du bloc passe **par-dessus**. **🎯 V2.2 — Cause racine d'un bug récurrent identifié** : si l'élément `<a:solidFill>` est ajouté en FIN du `<a:rPr>` (après `<a:latin>`), PowerPoint l'ignore silencieusement (violation de l'ordre XML imposé par le schéma OOXML : `solidFill` doit venir AVANT `latin`). Conséquence : le numéro apparaît **en noir** au lieu de la couleur palette. Toujours utiliser `rPr.insert(0, sf)` et NON `etree.SubElement(rPr, ...)`.
11. **L10 — chaque card contient 3 puces** : petit cercle plein 0,44 cm (couleur de la card) + **titre bold 11 pt `#000000` NOIR** + corps Segoe UI Light 10,5 pt `#474E67`, séparées par lignes 0,5 pt `#E0E0E8`.
12. **Polices Segoe UI** : nécessitent Windows/Office. Sur autre OS, prévoir un fallback explicite.
13. **Règle d'or** : *« Si j'hésite sur un point de layout → ce n'est pas de la créativité, c'est un point pas clair. Je demande, ou je fais un audit OOXML. »*
